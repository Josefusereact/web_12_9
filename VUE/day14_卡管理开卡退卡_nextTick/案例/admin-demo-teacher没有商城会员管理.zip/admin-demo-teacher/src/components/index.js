import Vue from 'vue'
import PPageHeader from './PageHeader.vue'
import PUpload from './Upload.vue'
Vue.component(PPageHeader.name,PPageHeader)
Vue.component(PUpload.name,PUpload)
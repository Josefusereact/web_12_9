<template>
	<div>
		test
		<input type="text">
	</div>
</template>

<script>
	
	export default{
		name:'test-user'
	}
</script>

<style>
</style>

module.exports = {
  lintOnSave:false
}
<template>
	<div class="page">
		<p-page-header title="考勤范围设置"></p-page-header>
		<p-map></p-map>
	</div>
</template>


<script>
	
	import PMap from '@/components/Map.vue'
	export default{
		name:'check-scope',
		components:{
			PMap
		},
		created(){
			
		}
	}
</script>

<style>
</style>

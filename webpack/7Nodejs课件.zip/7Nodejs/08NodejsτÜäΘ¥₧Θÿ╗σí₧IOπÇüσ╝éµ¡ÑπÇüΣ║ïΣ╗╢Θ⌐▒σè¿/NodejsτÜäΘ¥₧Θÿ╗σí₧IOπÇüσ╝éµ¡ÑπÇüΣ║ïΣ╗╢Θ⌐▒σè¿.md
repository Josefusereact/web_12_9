# Nodejs的非阻塞IO、异步、事件驱动

# 一、、 Nodejs的单线程 非阻塞I/O事件驱动

在Java、PHP或者.net等服务器端语言中，会为每一个客户端连接创建一个新的线程。而每个线程需要耗费大约2MB内存。也就是说，理论上，一个8GB内存的服务器可以同时连接的最大用户数为4000个左右。要让Web应用程序支持更多的用户，就需要增加服务器的数量，而Web应用程序的硬件成本当然就上升了。 Node.js不为每个客户连接创建一个新的线程，而仅仅使用一个线程。当有用户连接了，就触发一个内部事件，通过非阻塞I/O、事件驱动机制，让Node.js程序宏观上也是并行的。使用Node.js，一个8GB内存的服务器，可以同时处理超过4万用户的连接。

# 二、获取异步的两种方法

回调和events

## 2.1 Nodejs回调处理异步

### 2.1.1错误的写法： 



#### 案例一:非阻塞I/O

```js
var fs=require('fs');

console.log('1');

fs.readFile('mime.json',function(err,data){
   console.log(data);
   console.log('2');
})

console.log('3');
```

结果是：1、3、2

#### 案例二：非阻塞I/O

```js
function getMime(){

    //1
    fs.readFile('mime.json',function(err,data){
        //console.log(data.toString());

        return data;//3
    })
    //2
    //return '123';
}
console.log(getMime());  /*异步请求*/
```

结果是： undefined

#### 案例三：非阻塞I/O

```js

function getData(){ 
    //模拟请求数据 
    var result='';
    setTimeout(function(){ 
        result='这是请求到的数据' 
    },200); 
    return result; 
} 
console.log(getData());/*异步导致请求不到数据*/
```

### 2.1.2正确的处理异步：

```js
var fs=require('fs');
function getMime(callback){

    fs.readFile('mime.json',function(err,data){
        //console.log(data.toString());
        //return data;
        callback(data);
    })

}
getMime(function(result){

    console.log(result.toString());
})
```





```js
// 
function getData(callback){ 
    //模拟请求数据 
    var result=''; 
    setTimeout(function(){ 
        result='这是请求到的数据'; 
        callback(result); 
    },200); 
} 
getData(function(data){ 
    console.log(data); 
});
```

## 2.2 Nodejs events模块处理异步

Node.js 有多个内置的事件，我们可以通过引入 events 模块，并通过实例化 EventEmitter 类来绑定和监听事件。

Node.js 事件循环:

 Node.js 是单进程单线程应用程序，但是通过事件和回调支持并发，所以性能非常高。
 Node.js 的每一个 API 都是异步的，并作为一个独立线程运行，使用异步函数调用，并处理并发。

 Node.js 有多个内置的事件，我们可以通过引入 events 模块，并通过实例化 EventEmitter 类来绑定和监听事件，

emit：   广播

on:         监听

 如下实例：

发送和通知



```js

// 引入 events 模块

var events=require('events');

//console.log(events);
//EventEmitter 类来绑定和监听事件。
var EventEmitter=new events.EventEmitter();


//监听to_parent的广播
EventEmitter.on('to_parent',function(data){
    //console.log('接收到了这个广播事件');
    console.log(data);
})

setTimeout(function(){
    console.log('开始广播...');
    //广播to_parent事件
    EventEmitter.emit('to_parent','发送的数据')

},1000);
```

再加入一个广播  to-mime

```js
var events=require('events');

//console.log(events);

var EventEmitter=new events.EventEmitter();

//广播 和接收广播

EventEmitter.on('to_mime',function(data){

    console.log(data);

})

//监听to_parent的广播
EventEmitter.on('to_parent',function(data){
    //console.log('接收到了这个广播事件');

    console.log(data);

    EventEmitter.emit('to_mime','给mime发送的数据')

})

setTimeout(function(){
    console.log('开始广播...');
    //广播to_parent事件
    EventEmitter.emit('to_parent','发送的数据')

},1000);
```

### 2.2.1通过nodejs Event事件获取数据



```js
var fs=require('fs');
var events=require('events');
var EventEmitter=new events.EventEmitter();
function getMime(callback){
    fs.readFile(__dirname+'/mime.json',function(err,data){
        EventEmitter.emit('data',data)
    })
}
getMime();/*ִ执行方法*/
//监听广播数据
EventEmitter.on('data',function(mime){

    console.log(mime.toString());
})

```

# 三、实例

## 3.1回调

上节课得到mime.json的文件，改成通过回调函数获取

原始文件nodejs\07\model\getmimefromfile_bac.js

```js
exports.getMime=function(fs,extname){  /*获取后缀名的方法*/
  //.html
    console.log('1');
    fs.readFile(__dirname+'/../mime.json',function(err,data){
        if(err){
            console.log(err,'mime.json文件不存在');
            return false;
        }
        // console.log(data.toString());
        var Mimes=JSON.parse(data.toString());
        console.log(Mimes[extname]);
        console.log('2');
        return Mimes[extname] || 'text/html';

    })
    console.log('3');
}
```

回调方式：注意多了第三个参数回调函数

```js
exports.getMime=function(fs,extname,callback){  /*获取后缀名的方法*/

    fs.readFile('./mime.json',function(err,data){

        if(err){
            console.log('mime.json文件不存在');
            return false;
        }
        //console.log(data.toString());

        var Mimes=JSON.parse(data.toString());

        var result= Mimes[extname] || 'text/html';

        callback(result)

    })


}
```

nodejs\08\00services5.js

```js

//引入http模块
var http = require('http');

//fs模块

var fs = require('fs');

//path模块
var path = require('path');  /*nodejs自带的模块*/

//url模块

var url = require('url');

//引入扩展名的方法是在文件里面获取到的。

var mimeModel = require('./model/getmimefromfile.js');

//console.log(mimeModel.getMime('.css'));   //获取文件类型

http.createServer(function (req, res) {



	//http://localhost:8001/news.html    /news.html
	//http://localhost:8001/index.html    /index.html

	//css/dmb.bottom.css

	//xxx.json?214214124

	var pathname = url.parse(req.url).pathname;

	console.log(pathname);

	if (pathname == '/') {
		pathname = '/index.html'; /*默认加载的首页*/
	}

	//获取文件的后缀名
	var extname = path.extname(pathname);

	if (pathname != '/favicon.ico') {  /*过滤请求favicon.ico*/
		//console.log(pathname);
		//文件操作获取 static下面的index.html

		fs.readFile(__dirname+'/static/' + pathname, function (err, data) {

			if (err) {  /*么有这个文件*/

				console.log('404');

				fs.readFile(__dirname+'static/404.html', function (error, data404) {
					if (error) {
						console.log(error);
					}
					res.writeHead(404, { "Content-Type": "text/html;charset='utf-8'" });
					res.write(data404);
					res.end(); /*结束响应*/
				})

			} else { /*返回这个文件*/

				var mime = mimeModel.getMime(fs, extname, function (mime) {
					res.writeHead(200, { "Content-Type": "" + mime + ";charset='utf-8'" });
					res.write(data);
					res.end(); /*结束响应*/
				});

			}
		})

	}

}).listen(8002);
```

测试：http://localhost:8002/index.html

## 3.2 events



```js
exports.getMime=function(fs,EventEmitter,extname){  /*获取后缀名的方法*/
    fs.readFile('./mime.json',function(err,data){
        if(err){
            console.log('mime.json文件不存在');
            return false;
        }
        //console.log(data.toString());
        var Mimes=JSON.parse(data.toString());
        var result= Mimes[extname] || 'text/html';
        EventEmitter.emit('to_mime',result);
    })
}
```

nodejs\08\00services6.js

引入events,创建对象

```js

//引入http模块
var http=require('http');

//fs模块

var fs=require('fs');

//path模块
var path=require('path');  /*nodejs自带的模块*/

//url模块

var url=require('url');


var events=require('events');

var EventEmitter=new events.EventEmitter();

var mimeModel=require('./model/getmimefromfile_events.js');
//引入扩展名的方法是在文件里面获取到的。
//console.log(mimeModel.getMime('.css'));   //获取文件类型

http.createServer(function(req,res){
	var pathname=url.parse(req.url).pathname;
	console.log(pathname);
	if(pathname=='/'){
		pathname='/index.html'; /*默认加载的首页*/
	}

	//获取文件的后缀名
	var extname=path.extname(pathname);

	if(pathname!='/favicon.ico'){  /*过滤请求favicon.ico*/
		//console.log(pathname);
		//文件操作获取 static下面的index.html

		fs.readFile(__dirname+'/static/'+pathname,function(err,data){

			if(err){  /*么有这个文件*/

				console.log('404');

				fs.readFile(__dirname+'/static/404.html',function(error,data404){
					if(error){
						console.log(error);
					}
					res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
					res.write(data404);
					res.end(); /*结束响应*/
				})

			}else{ /*返回这个文件*/
				mimeModel.getMime(fs,EventEmitter,extname);  /*调用获取数据的方法*/
				EventEmitter.on('to_mime',function(mime){
					res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
					//res.write(data);   出错，小心！！！！
					res.end(data); /*结束响应*/
				})
			}
		})
	}
}).listen(8002);
```


# NPM 命令使用  第三方模块和 package.json 

# 一、包与NPM

## 1.包

Nodejs中除了它自己提供的核心模块外，我们可以自定义模块，也可以使用第三方的模块。Nodejs中第三方模块由包组成，可以通过包来对一组具有相互依赖关系的模块进行统一管理。

在Node.js中，会将某个独立的功能封装起来，用于发布、更新、依赖管理和进行版本控制。Nodejs根据CommonJS规范实现了包机制，开发了NPM包管理工具，用来解决包的发布和获取需求。

​		CommonJS API定义很多用于非浏览器的应用使用的普通应用程序，而Node.js就是一个非浏览器的应用，CommonJS是一种规范，Node.js是这种规范的部分实现。

![image-20200206162230207](文档中的图片/image-20200206162230207.png)



完全符合CommonJs 规范的`包`目录一般包含如下这些文件。

- package.json :包描述文件。
- bin :用于存放可执行二进制文件的目录。
- lib :用于存放JavaScript 代码的目录。
- doc :用于存放文档的目录。

在实际开发中，当某个包需要发布到网上，供他人使用时，最好遵守CommonJS规范。Nodejs包中包含JSON格式的包说明文件package.json。在规范中package.json文件好比一个产品说明书，它的优势在于当开发者拿到一个第三方包文件时，可以对包的信息一目了然。在NodeJs 中通过`npm` 命令来下载第三方的模块（包）。



## 2.案例

在www.npm.com网站去找包， 例如下面格式化日期的包

https://www.npmjs.com/package/silly-datetime

首先找到一个文件夹，命令行进入到这个目录，运行下面代码

```bash
npm i silly-datetime --save
```

会生成node_modules,自定义模块就放在这个目录中



```js

var sd = require('silly-datetime');
sd.format(new Date(), 'YYYY-MM-DD HH:mm');
```



升级一下

commonjs01.js

```js
//1.npm i silly-datetime
//2.引入模块
var sd = require('silly-datetime');
var http=require('http');
var app=http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type":"text/html;charset=utf-8"});
    //var d=sd.format(new Date(), 'YYYY-MM-DD HH:mm');
    var d=sd.format(new Date(), 'YYYY-MM-DD');
    res.write('你好 nodejs'+d);
    res.end();
})
app.listen(8002,'127.0.0.1');
```



# 二、NPM 介绍

​		NPM的全称是Node.js package manage，在Node.js中有两种含义：一种含义是Node.js的开放模块登记和管理系统，是一个NPM[网站][https://www.npmjs.com],该网站是全球最大的模块生态系统。另一种含义是Node.js的包管理工具，一个命令行下的软件，提供了一些命令用于快速的安装和管理模块。

npm 是世界上最大的开放源代码的生态系统。我们可以通过npm 下载各种各样的包，
这些源代码（包）我们可以在https://www.npmjs.com 找到。
		npm 是随同NodeJS 一起安装的包管理工具，能解决NodeJS 代码部署上的很多问题，
常见的使用场景有以下几种：

- 允许用户从NPM 服务器下载别人编写的第三方包到本地使用。(silly-datetime)
- 允许用户从NPM 服务器下载并安装别人编写的**命令行程序**(工具)到本地使用。
  （supervisor）
- 允许用户将自己编写的包或命令行程序上传到NPM 服务器供别人使用。

# 三、NPM 命令详解。

<img src="文档中的图片/image-20200206182050187.png" alt="image-20200206182050187" style="zoom:150%;" />

1. npm -v 查看npm 版本

2. 使用 npm 命令安装模块

   ```bash
   npm install Module Name
   //如安装jq 模块：, jquery是前端的框架在nodejs里是不能使用的
   npm install jquery
   ```

   

3. npm uninstall moudleName 卸载模块
   npm uninstall ModuleName

4. npm list 查看当前目录下已安装的node 包
    npm list

5. npm info jquery 查看jquery 的版本
    npm info 模块 //查看模块的版本

6. 指定版本安装 npm install jquery@1.8.0

# 四、包模块加载规则

​		第2章中介绍过require()的加载规则，了解了文件模块和核心模块，在require()的加载规则中还有一个特殊的文件模块，叫作包模块。包模块既不是文件模块标识，也不是核心模块标识，也就是说当需要加载的模块名称既不是路径，也不是内置模块名称时，就是包模块的名称。

​		包模块的加载规则如下所示：

* 在加载的时候，Node.js默认会把它当做核心模块去加载，如果发现标识名不是核心模块，就会在当前目录的node_moudules目录下寻找。如果没有找到，Node.js会从当前目录的父目录的node_modules里搜索，这样递归下去直到根目录。

* 如果找到了该标识名的子目录，Node.js将会找到该子目录下的package.json文件，获取该文件中main属性的值，根据main属性指定的路径值进行加载。这样做的好处是在用户使用第三方模块的时候，不用关心入口模块是哪个文件。

  让我们更好的理解require()包加载规则，下面通过一个案例进行演示

  1.在C:\Course\code\chapter03目录下创建目录lib。

  2.在lib目录下创建demo.js文件，添加代码

  ```javascript
   var markdown = require('markdown');
  ```

  3.在C:\Course\code\chapter03\lib目录下创建node_moudules\markdown\lib目录，在该目录下创建index.js

  ```javascript
  console.log("index.js文件模块被加载了") ;
  ```

  4.在C:\Course\code\chapter03\lib\markdown目录下创建package.json文件

  ```json
  {
   "main": "./lib/index.js"
  }
  ```

  

  <img src="文档中的图片/image-20200206191802408.png" alt="image-20200206191802408" style="zoom:200%;" />

  

  <img src="文档中的图片/image-20200206191814346.png" alt="image-20200206191814346" style="zoom:200%;" />

  ​		从执行结果可以看出在demo.js中加载我们自己创建的markdown模块时，由于demo.js文件在chapter03\lib目录下，所以优先查找了chapter03\lib目录下的node_modules目录，在该目录下查找markdown目录下的package.json文件，然后根据package.json文件main属性指定的目录找到index.js文件。

  ​		上述案例演示了chapter03\lib目录下存在node_modules目录的情况，为了演示不在下的情况，接下来删除自己创建的node_modules目录，删除后的目录。

  ​		![image-20200206194537161](文档中的图片/image-20200206194537161.png)

  ​	按照包的加载规则，这时执行demo.js文件，应该去chapter03\lib的父目录chapter03中的node_modules目录查找，这个目录就是使用NPM安装的markdown时出现的。与模拟的node_modules目录相似，打开该目录找到markdown/package.json文件，可以看到加载的入口模块就是index.js。

  ​	![image-20200206200104734](文档中的图片/image-20200206200104734.png)

  ​	打开index.js文件可以看到以下代码：

  ```javascript
  exports.markdown = require("./markdown");
  exports.parse = exports.markdown.toHTML;
  ```

  上述代码的意思是，当加载该文件时会得到一个名称为markdown的对象，该对象中的toHTML方法可以在页面输出标签。根据Markdown包官方的使用方法，修改demo.js文件代码如下。

  ```javascript
  var markdown = require('markdown').markdown;
  console.log(markdown.toHTML("#hello"));
  
  ```

  验证了当文件当前目录不存在node_modules目录时，会去父目录查找。

  ![image-20200206200327404](文档中的图片/image-20200206200327404.png)

# 五、package.json

package.json 定义了这个项目所需要的各种模块,以及项目的配置信息(比如名称、版本、许可证等元数据)

## 1、创建package.json

```bash
npm init  使用向导的方式一步一步按提示生成
npm init –yes  快速生成，使用默认的值
```

## 2、package.json 文件

```js
{
  "name": "npmdemo",
  "version": "1.0.0",
  "description": "",
  "main": "commonjs01.js",
  "dependencies": {
    "silly-datetime": "^0.1.2"
  },
  "devDependencies": {
    "md5-node": "^1.0.1"
  },
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC"
}

```

如果把项目给别人，因为node_modules很多包很大，可以删除掉给别人



```js
npm install
```

会根据package.json中的依赖下载包

## 3、安装模块并把模块写入package.json(依赖)

```bash
npm install babel-cli --save-dev
npm install 模块 --save      写入到package.json 里面的  dependencies
npm install 模块 --save-dev  写入到package.json 里面的  devDependencies
```

注意：以后安装模块的时候我们要把这个模块写入到package.json这个配置文件

## 4、dependencies 与devDependencies 之间的区别?

使用`npm install node_module –save` 自动更新dependencies 字段值;
使用`npm install node_module –save-dev `自动更新devDependencies 字段值;
dependencies            配置当前程序所依赖的其他包。
devDependencies     配置当前程序所依赖的其他包，只会下载模块，而不下载这些模块的测试和文档框架

```js
"dependencies": {
	"ejs": "^2.3.4",
	"express": "^4.13.3",
	"formidable": "^1.0.17"
}
```



- ^表示第一位版本号不变，后面两位取最新的
- ~表示前两位不变，最后一个取最新
- *表示全部取最新

# 六、安装淘宝镜像

http://www.npmjs.org npm 包官网
https://npm.taobao.org/ 淘宝npm 镜像官网
淘宝 NPM 镜像是一个完整 npmjs.org 镜像，你可以用此代替官方版本(只读)，同步频
率目前为 10 分钟 一次以保证尽量与官方服务同步。
我们可以使用我们定制的 cnpm (gzip 压缩支持) 命令行工具代替默认的 npm:

```js
npm install -g cnpm --registry=https://registry.npm.taobao.org
```



/*

 npm 安装了nodejs就会有npm 。


 supervisor改代码自动重启web服务

 npm -g install supervisor


 supervisor app.js


运行nodejs   node js文件


 supervisor js文件




* */
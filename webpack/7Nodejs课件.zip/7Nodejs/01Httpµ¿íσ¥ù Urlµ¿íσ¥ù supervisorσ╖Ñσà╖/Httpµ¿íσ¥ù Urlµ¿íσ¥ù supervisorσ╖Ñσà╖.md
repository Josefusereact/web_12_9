# 初识Node.js

# Http模块 Url模块 supervisor工具

## 一、Node.js概述

### 1.1学习Nodejs的目的

​		随着互联网的发展，全栈工程师（Full Stack Engineer）的概念开始兴起，全栈即包括用户界面、业务逻辑、数据建模、服务器、网络及环境等。这意味着，全栈工程师要熟练处理各层间的交互。而现在，有了Nodejs的出现，用JavaScript语言既可以进行客户端开发，又可以进行服务器端的开发，还可以与数据库交互。

​		用node可以进行网站开发、在线游戏的后台服务器、物联网开发的软件部分、控制台应用程序、数据交互等

### 1.2 客户端和服务器

​		既然nodejs是用于服务端的开发，就要弄明白什么事客户端和服务器。

#### 1.2.1 传统的客户端与服务端

​       		![image-20200205100015602](文档中的图片/image-20200205100015602.png)

#### 1.2.2 Nodejs的客户端与服务端

![image-20200205100129166](文档中的图片/image-20200205100129166.png)

#### 1.2.3 一个用户登录的例子

<img src="文档中的图片/image-20200205101202450.png" alt="image-20200205101202450" style="zoom: 200%;" />





### 1.3 Javascript 在客户端和服务端的区别

​		Javascript一般运行在客户端， 而nodejs可使JavaScript运行在服务端。

​		回顾JavaScript包括ECMAScript、DOM和BOM 3各部分

​		(1) ECMAScript是Javascript的核心语法

​		(2) DOM是HTML和XML的应用程序接口（API），用于控制文档内容和结构

​		(3) BOM浏览器对象模型， 可以对浏览器窗口进行访问和操作	

​		在客户端，JavaScript需要依赖浏览器提供的JavaScript引擎解析执行，浏览器还提供了对DOM的解析，所以客户端的JavaScirpt不仅应用核心语法ECMAScript，还会操作DOM和BOM，常见的应用场景如用户交互、动画特效、表单验证、发送Ajax请求等。

​		在服务端，JavaScript不依赖浏览器，而是由特定的运行环境提供的JavaScript引擎解析执行，例如Node.js。服务端的JavaScirpt应用核心语法ECMAScript，但是不操作DOM和BOM。它常常用来做一些在客户端做不到的事情，例如操作数据库、操作文件等，另外，在客户端的Ajax操作只能发送请求，而接受请求和做出响应的操作就需要服务端的JavaScript来完成。

​		简而言之，客户端的JavaScript主要用来处理页面的交互，而服务端的JavaScript主要用来处理数据的交互。

## 二、 nodejs简介

​		Node.js是由作者Ryan Dahl于2009年5月推出的最初版本，Ryan Dahl是一名专注与实现高性能web服务器的优化专家，他将Chrome浏览器的V8引擎单独移植出来，在这个基础之上，为其上层的JavaScript提供了友好的API，供开发人员使用，而且完全开源免费。

![image-20200205102150814](文档中的图片/image-20200205102150814.png)

![image-20200205102405123](文档中的图片/image-20200205102405123.png)

Nodejs的特点

（1）它是一个Javascript运行环境。

（2）依赖于Chrome V8引擎进行代码解析。

（3）事件驱动（event-driven）。

（4）非阻塞I/O（non-blocking I/O）。

（5）轻量、可伸缩，适于实时数据交互应用。

（6）单进程，单线程。

## 2.1Node.js的安装与配置

 ## 2.2 下载与安装

[官网下载链接][https://nodejs.org/en/download/]

https://nodejs.org/en/download/

![image-20200205103042908](文档中的图片/image-20200205103042908.png)

node-v12.14.1-x64适合64位的操作系统

node-v12.14.1-x86适合32位的操作系统

![image-20200205103524154](文档中的图片/image-20200205103524154.png)

![image-20200205103544839](文档中的图片/image-20200205103544839.png)

![image-20200205103557506](文档中的图片/image-20200205103557506.png)

## 2.3 CMD命令行

​		CMD命令台在实际开发中常常被称为“终端”、“Shell”，为了符合多数人的习惯，CMD命令台均称为“终端”。

​		打开CMD命令台

​		![image-20200205104219931](文档中的图片/image-20200205104219931.png)

​		输入命令“node –v”

​		![image-20200205104354514](文档中的图片/image-20200205104354514.png)

​		终端的常用命令如下所示：

​		dir（directory）：查看当前目录下所有的条目

​		cd（change directory）： 切换目录

​		cls|clear（clear screen）：清屏

## 2.4 Path环境变量

​		node -v命令的可执行文件 `node.exe` 在安装目录c:\program files\nodejs下，但是我们在c:\users\admin目录下问什么也能使用node.exe？	

​		它的作用是告诉系统，当要求系统运行一个程序，而没有告诉它程序所在的完整路径时，系统除了在当前目录下面寻找此程序外，还应到哪些目录下去寻找。如果在Path环境变量中配置了.exe文件的路径，那么在任何路径下使用“node”命令都可以找到“node.exe”文件。Node.js的安装过程中，已经在path环境变量中配置好了“node.exe”的路径。

​		（1）在操作系统中，右击“计算机”，找到“高级系统设置”

​		（2）在“高级系统设置”中找到“环境变量”

![image-20200205110004954](文档中的图片/image-20200205110004954.png)

​		（3）单击“环境变量”，找到变量Path

![image-20200205110018274](文档中的图片/image-20200205110018274.png)

​		（4）单击“Path”，在后面可以看到“node.exe”的文件路径

![image-20200205110035291](文档中的图片/image-20200205110035291.png)

## 2.5快速体验Nodejs

### 2.5.1Hello world

​		（1）创建目录C:\Course\code，这个目录用于放置以后学习过程中所有章节的代码文件。

​		（2）在C:\Course\code目录下创建目录chapter02

​		（3）在chapter02目录下创建demo2-1.js

​					console.log('hello world');

​		（4）打开终端，切换到demo2-1.js文件所在的目录，并输入“node demo2-1.js”，

​			![image-20200205110833639](文档中的图片/image-20200205110833639.png)

### 2.5.2 最简单的服务端Web程序

```javascript
//加载http模块
var http = require('http');
//创建http服务器
http.createServer(function(req, res) {
  //响应结束
  res.end('hello world');
  //监听网址127.0.0.1 端口号3000
}).listen(3000,'127.0.0.1');
```

此时在浏览器中访问网址http://127.0.0.1:3000/

## 三、Nodejs基础入门

## 3.1 REPL运行环境

​		为了使开发者方便测试JavaScript代码，Node.js中提供了一个名为REPL（Read-Eval-Print-Loop）的可交互运行环境，当开发者输入JavaScript表达式，按下回车键后，REPL运行环境中将显示该表达式的运行结果。

​		打开终端，输入“node”命令并按下回车键，即可进入REPL运行环境

​		![image-20200205114746890](文档中的图片/image-20200205114746890.png)

​		Node.js为REPL运行环境提供了一些常用命令

​		![image-20200205114824140](文档中的图片/image-20200205114824140.png)

​		Chrome浏览器的Console也是一个REPL运行环境

## 3.2 global对象和模块作用域

​		之前客户端JavaScript的使用过程中，在浏览器中默认声明的变量、函数都属于全局对象window。所谓全局对象中的所有变量和函数子全局作用域内都是有效的。

#### 	1.理解global对象和模块作用域

​		在nodejs中，默认就是模块化的，声明的变量、函数都属于当前文件模块，都是私有的，只在当前模块作用域内可以使用，那么nodejs中是否只有模块作用域？答案是肯定否定的，如果想在全局范围内为某个变量赋值，可以通过global。

​		Node.js中的global对象类似于浏览器中的Window对象，用于定义全局命名空间，所有全局变量（除了 global 本身以外）都是 global 对象的属性，在实际使用中可以省略global。，global 对象能够实现文件模块与文件模块之间的数据共享。

```javascript
var foo = 'bar';
console.log(foo);
//global对象这时是没有foo属性的
console.log('global:foo '+global.foo);
//为global对象挂载一个foo变量，并将该文件模块中foo的值赋值给它
global.foo = foo;
//这是global.foo的值为'bar'
console.log('global:foo '+global.foo);
```

​		在Node.js中，global对象定义了全局命名空间。当我们定义了一个全局变量时，这个变量同时也会成为全局对象global的属性，反之亦然。可以说在全局作用域中，任何变量、函数和对象都是global对象的一个属性值。	

​		global对象能够实现文件模块与文件模块之间的数据共享。

​		虽然解决了文件模块之间的数据共享，但是多处使用全局变量会污染命名空间，容易造成耦合的问题。

#### 2.require() 、exports、module.exports

​		![image-20200205150507112](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200205150507112.png)

​		为了解决上诉问题，nodejs提供了一个简单的模块系统，其中

​		`exports`是模块公开的接口

​		`require()` 函数用于从外部获取一个模块的接口，即获取模块的exports对象

​		要在一个文件模块中***获取***其他文件模块的内容，首先需要使用require()函数加载这个模块，在被加载的模块中使用exports或者module.exports对象向外开放变量、函数等。require()函数的作用是加载文件并获取该文件中module.exports对象接口。

​		下面通过一个案例来演示在nodejs中如何进行模块之间内容的共享。

demo2-4/info.js

```javascript
//向外暴漏变量name
exports.name = 'oracle';
exports.type='edu';
//向外暴漏变量age
module.exports.age='10';
//向外暴漏函数
module.exports.sayHello= function () {
    console.log('hello');
}
```

demo2-4/demo2-4.js

```javascript
//加载模块
var myModule = require('./info');
console.log(myModule);
//输出模块中的变量值
console.log('name:'+myModule.name);
console.log('type:'+myModule.type);
console.log('age:'+myModule.age);
//调用模块的方法
myModule.sayHello();
```

注意这里由于是相对路径，需要加“./”。加载完毕后将返回一个module.exports对象，在该对象中饮食了所加载模块对外开放的变量、函数、对象等。

![image-20200205150335228](文档中的图片/image-20200205150335228.png)

exports肯module.exports都可以对外开放变量或者函数，它们的区别是什么？

为了让开发者使用起来更方便，提供了exports,它是一个指向的module.exports的引用， module.exports初始值为一个空对象{},所以exports初始值也是{}。而module.exports可以单独定义，返回数据类型，而exports只能是返回一个object对象。下面通过例子演示两者的区别。

demo2-5/test.js

```javascript
//定义一个数组
//module.exports=['name','type','age'];
exports=['name','type','age'];
```

demo2-5/demo2-5.js

```javascript
//加载模块
var myModule = require('./test');
console.log(myModule);
//输出数组长度
console.log('length:'+myModule.length);
```

分别注释test.js的第2行和第3行代码看到执行结果，使用exports直接定义数据，会切断exports与module.exports的联系，出现找不到值的情况。由此可见，exports不能单独定义并返回数据类型。

## 3.3 全局可用变量、函数和对象

#### 1.理解全局作用域

​		在Node.js中，global对象定义了全局命名空间。当我们定义了一个全局变量时，这个变量同时也会成为全局对象global的属性，反之亦然。可以说在全局作用域中，任何变量、函数和对象都是global对象的一个属性值。

#### 2理解“全局变量”

​		本节要介绍的是，在nodejs中提供一些全局可用的变量、函数和对象，这里所谓的全局就是不需要进行模块加载，可以直接使用的，其中包括全局作用域的函数和对象。也包括另一种不在全局作用域，而是在每个模块作用域都存在的变量、函数和对象，在全局可用，但不是global的属性。

​		例如require()函数，在每个模块作用域中存在，所有不需要加载可以使用，我们可以说它是全局可用，但它不是全局函数。可以到官网查看api目录，

![image-20200205170101562](文档中的图片/image-20200205170101562.png)

![image-20200205170833478](文档中的图片/image-20200205170833478.png)

点击右侧导航`Globals`查看到这些全局变量、函数和对象

#### 3.\_\_dirname和\_\_filename变量

_dirname表示当前文件所在的目录

_filename表示当前正在执行的脚本的文件名。

```javascript
// 输出全局变量 __dirname 的值
console.log('文件的目录是：'+ __dirname );
// 输出全局变量 __filename 的值
console.log('文件的绝对路径是：'+__filename );
```

#### 4.全局函数

<img src="文档中的图片/image-20200205171145693.png" alt="image-20200205171145693" style="zoom:150%;" />

#### 5.console对象

<img src="文档中的图片/image-20200205171458650.png" alt="image-20200205171458650" style="zoom:150%;" />



# 二、Node.js 创建第一个应用

如果我们使用 PHP 来编写后端的代码时，需要 Apache 或者 Nginx 的 HTTP 服务器，
来处理客户端的请求相应。不过对 Node.js 来说，概念完全不一样了。使用 Node.js 时，
我们不仅仅在实现一个应用，同时还实现了整个 HTTP 服务器。

## 1、引入 http 模块

```js
var http = require("http");
```

## 2、创建服务器

接下来我们使用 http.createServer() 方法创建服务器，并使用 listen 方法绑定 8888 端口。
函数通过 request, response 参数来接收和响应数据。

```js
var http = require('http');
http.createServer(function (request, response) {
    // 发送 HTTP 头部
    // HTTP 状态值: 200 : OK
    //设置 HTTP 头部，状态码是 200，文件类型是 html，字符集是 utf8
    response.writeHead(200, { "Content-Type": "text/html;charset=UTF-8" });
    // 发送响应数据 "Hello World"
    res.end("哈哈哈哈，我买了一个 iPhone" + (1 + 2 + 3) + "s");
}).listen(8888);
// 终端打印如下信息
console.log('Server running at http://127.0.0.1:8888/');

```

## 3.运行程序

用命令行切换到程序对应目录。通过 node 命令运行程序。

![image-20200820220828829](images\image-20200820220828829.png)

浏览器运行 http://localhost:8888

你会发现，我们本地写一个 js，打死都不能直接拖入浏览器运行，但是有了 node，我
们任何一个 js 文件，都可以通过 node 来运行。也就是说，node 就是一个 js 的执行环境。

# 二、HTTP 模块、URL 模块

Node.js 中，将很多的功能，划分为了一个个 module（模块）。 Node.js 中的很多功能都
是通过模块实现。

## 2.1、HTTP 模块的使用

```js
//引用模块
var http = require("http");
//创建一个服务器，回调函数表示接收到请求之后做的事情
var server = http.createServer(function (req, res) {
    //req 参数表示请求，res 表示响应
    console.log("服务器接收到了请求" + req.url);
    res.end(); // End 方法使 Web 服务器停止处理脚本并返回当前结果
});
//监听端口
server.listen(3000, "127.0.0.1");
```

设置一个响应头：

```js
res.writeHead(200,{"Content-Type":"text/html;charset=UTF8"});
```

![image-20200820222100893](images\image-20200820222100893.png)

我们现在来看一下 req 里面能够使用的东西。最关键的就是 req.url 属性，表示用户的请求 URL 地址。所有的路由设计，都是通过 req.url来实现的。我们比较关心的不是拿到 URL，而是识别这个 URL。识别 URL，用到了下面的 url 模块



## 2.2、URL 模块的使用

> url.parse() 解析 URL
> url.format(urlObject) //是上面 url.parse() 操作的逆向操作
> url.resolve(from, to) 添加或者替换地址



### 1、url.parse()

![image-20200821203459095](images\image-20200821203459095.png)

传参数的例子

![image-20200821210035420](images\image-20200821210035420.png)

拿到了目录，查询参数第二个true参数可以把query:变成对象

![image-20200821210533668](images\image-20200821210533668.png)

### 2、url.format()

一般用不到，与parse相反，把一个对象变成一个url地址

### 3、url.resolve()

添加或者替换地址

![image-20200821211058257](images\image-20200821211058257.png)

完善代码

```js
var http = require('http');
var url = require('url');

//2.用http模块创建服务
/*
 req获取url信息   （request）
 res 浏览器返回响应信息 （response）
 * */
http.createServer(function (req, res) {
    //输入http://localhost:8001/news?aid=123   拿到aid
    // 输入http://localhost:8001/news?aid=123&cid=3   拿到aid 和cid
    //req.url  获取浏览器url输入的信息
    //var query=url.parse(req.url,true);
    //
    //
    //console.log(query);
    res.writeHead(200, { "Content-Type": "text/html;charset=utf-8" });
    if (req.url != '/favicon.ico') {
        //http://localhost:8001/news?aid=123
        //console.log(req.url);  //返回  /news?aid=123
        var result = url.parse(req.url, true);  //第一个参数是地址    第二个参数是true的话表示把get传值转换成对象
        console.log('aid=' + result.query.aid);  /*获取url的get传值*/
        console.log('cid=' + result.query.cid);
    }
    res.write('你好 nodejs');
    res.end(); /*结束响应*/
}).listen(8001);
```



# 三、Nodejs 自启动工具 supervisor/nodemon

supervisor 会不停的 watch 你应用下面的所有文件，发现有文件被修改，就重新载入程序文件这样就实现了部署，修改了程序文件后马上就能看到变更后的结果。麻麻再也不用担心我的重启 nodejs 了！

## 3.1.首先安装 supervisor/nodemon

```bash
npm install -g supervisor
npm install -g nodemon
```

## 3.2使用 supervisor 代替 node 命令启动应用

```BASH
supervisor "02 url模块.js"
nodemon [your node app]
```


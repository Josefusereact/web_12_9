//�˷�
module.exports = function (x, y) {
  return parseInt(x) * parseInt(y)
}

/**
 * Created by Administrator on 2017/5/8 0008.
 */

/*这个config文件就是config配置文件模块*/
var str='this is config';


exports.str=str;  /*暴露模块*/
//module.exports=str;
/**
 * Created by Administrator on 2017/5/8 0008.
 */


var tools={

    add:function(x,y){
        return x+y;
    },
    sayHello:function(){

        return '你好 nodejs'
    }

}

//exports.tools=tools;

// module.exports=tools;
exports = module.exports = tools
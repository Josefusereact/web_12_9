

var app=function(){

    console.log('app');
}

app.get=function(){
    console.log('app.get');
}
app.post=function(){
    console.log('app.post');
}


app.post() /*app.post*/

//
app()   /*app*/

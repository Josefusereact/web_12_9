
//fs模块

var fs=require('fs');
//path模块
var path=require('path');  /*nodejs自带的模块*/
//url模块
var url=require('url');


/**
 * 
 * @param {*} req  请求
 * @param {*} res  响应
 * @param {*} staticpath    静态目录
 */
exports.statics=function(req,res,staticpath){


    var pathname=url.parse(req.url).pathname;   /*获取url的值ֵ*/


    if(pathname=='/'){
        pathname='/index.html'; 
    }
    var extname=path.extname(pathname);

    if(pathname!='/favicon.ico'){ 
        //！！！！！路径
        fs.readFile(staticpath+'/'+pathname,function(err,data){

            if(err){  

                console.log('404');

                fs.readFile(staticpath+'/404.html',function(error,data404){
                    if(error){
                        console.log(error);
                    }
                    res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
                    res.write(data404);
                    res.end(); 
                })

            }else{ /*返回这个文件*/

               getMime(extname,function(mime){
                    res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
                    res.write(data);
                    res.end(); /*结束响应*/
                });

            }
        })

    }

}
//获取文件类型的MIME，私有方法
function getMime(extname,callback){  

    fs.readFile('./mime.json',function(err,data){

        if(err){
            console.log('mime.json没找见');
            return false;
        }
        //console.log(data.toString());

        var Mimes=JSON.parse(data.toString());

        var result= Mimes[extname] || 'text/html';

        callback(result)

    })


}
const fs = require('fs')

//流的方式读取文件

var readStream=fs.createReadStream(__dirname+'/input.txt');

var str='';/*保存数据*/
var count=0;  /*次数*/
readStream.on('data',function(chunk){
    str+=chunk;
    count++;

})

//读取完成
readStream.on('end',function(chunk){
    console.log('完成'+count);
    console.log(str);

})


//读取失败
readStream.on('error',function(err){
    console.log(err);

})
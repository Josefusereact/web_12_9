# Nodejs WEB服务器 静态文件托管、 GET POST路由 EJS模板引擎

# 1、 Nodejs 静态文件托管

回顾上一讲已经实现了静态文件的处理，createServer一些代码太乱了

 这一章讲静态web服务器封装

## 1.1封装一个router.js

```js
//fs模块

var fs=require('fs');
//path模块
var path=require('path');  /*nodejs自带的模块*/
//url模块
var url=require('url');


/**
 * 
 * @param {*} req  请求
 * @param {*} res  响应
 * @param {*} staticpath    静态目录
 */
exports.statics=function(req,res,staticpath){
    var pathname=url.parse(req.url).pathname;   /*获取url的值ֵ*/
    if(pathname=='/'){
        pathname='/index.html'; 
    }
    var extname=path.extname(pathname);
    if(pathname!='/favicon.ico'){ 
        //！！！！！路径
        fs.readFile(staticpath+'/'+pathname,function(err,data){

            if(err){  

                console.log('404');

                fs.readFile(staticpath+'/404.html',function(error,data404){
                    if(error){
                        console.log(error);
                    }
                    res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
                    res.write(data404);
                    res.end(); 
                })

            }else{ /*返回这个文件*/

               getMime(extname,function(mime){
                    res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
                    res.write(data);
                    res.end(); /*结束响应*/
                });

            }
        })

    }

}
//获取文件类型的MIME，私有方法
function getMime(extname,callback){  

    fs.readFile('./mime.json',function(err,data){

        if(err){
            console.log('mime.json没找见');
            return false;
        }
        //console.log(data.toString());

        var Mimes=JSON.parse(data.toString());

        var result= Mimes[extname] || 'text/html';

        callback(result)

    })
}
```

nodejs\09\00services1.js  ,调用路径处理

```js
//引入http模块
var http=require('http');
//引入扩展名的方法是在文件里面获取到的。
var router=require('./model/router.js');
//console.log(mimeModel.getMime('.css'));   //获取文件类型
http.createServer(function(req,res){
	router.statics(req,res,'static');
	console.log(req.url);
}).listen(8001);
```





# 2、 路由（Routing）

- 官方解释： 路由是由一个 URI（或者叫路径）和一个特定的 HTTP 方法（GET、POST 等）组成的，涉及到应用如何响应客户端对某个网站节点的访问。 

- 非官方解释： 路由指的就是针对不同请求的URL，处理不同的业务逻辑。

  ![image-20200823165000854](images\image-20200823165000854.png)

如上图所示，当你访问不同的url,   走不同的方法处理

## 2.1实现路由

一个简单的路由实现

```js

//引入http模块
var http=require('http');

var url=require('url');
//路由:指的就是针对不同请求的 URL，处理不同的业务逻辑。
http.createServer(function(req,res){
	var pathname=url.parse(req.url).pathname;
	if(pathname=='/login'){
		res.end('login');
	}else if(pathname=='/register'){
		res.end('register');
	}else if(pathname=='/order'){
		res.end('order');
	}else{
		res.end('index');
	}
}).listen(8001);
```

# 3、 初识EJS模块引擎 

我们学的EJS是后台模板，可以把我们数据库和文件读取的数据显示到Html页面上面。它是一个第三方模块，需要通过npm安装
https://www.npmjs.com/package/ejs 安装： npm install ejs –save / cnpm install ejs --save
Nodejs中使用：

```bash
npm install ejs –save / cnpm install ejs --save
```

在工程目录中使用上面命令

## 3.1使用EJS

把一个数组（可能是从数据库取出的数据）渲染到模板上面

### 3.1.1首先引用ejs

```js
var ejs=require('ejs');
```

### 3.1.2建立模版文件

新建文件夹nodejs\09\views\

新建文件nodejs\09\views\index.ejs  ，其实就是html文件

```ejs
<html>
<head>
  <title></title>
</head>
<body>
    <h2>这是一个ejs的后台模板引擎</h2>
</body>
</html>
```

### 3.1.2建立login.ejs和register.ejs

nodejs\09\views\login.ejs

```ejs
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <title></title>
</head>
<body>
    <h2>这是一个ejs的后台模板引擎-登录</h2>
    <h2><%=msg%></h2>
    <br/>
    <hr/>
    <ul>
        <% for(var i=0;i<list.length;i++){%>
            <li><%=list[i]%></li>
        <% } %>
    </ul>
</body>
</html>
```

新建nodejs\09\views\register.ejs

```ejs
<html>
<head>
  <title></title>
</head>
<body>
    <h2>注册</h2>
    <%=msg%>
    <br/>
    <%-h%>
</body>
</html>
```



### 3.1.3把数据渲染到ejs文件中

renderFile函数

```js
ejs.renderFile(filename, data, options, function(err, str){ 
    // str => Rendered HTML string 
});
```

EJS常用标签 

-  <% %>流程控制标签
-  <%= %>输出标签（原文输出HTML标签） 
-  <%- %>输出标签（HTML会被浏览器解析）  查看register.ejs例子



```js
//引入http模块
var http=require('http');
var url=require('url');
var ejs=require('ejs');
//路由:指的就是针对不同请求的 URL，处理不同的业务逻辑。
http.createServer(function(req,res){
	res.writeHead(200,{"Content-Type":"text/html;charset='utf-8'"});
	var pathname=url.parse(req.url).pathname;
	if(pathname=='/login'){
		var data='你好我是后台数据';
		var list=[
			'1111',
			'2222',
			'3333',
		];
		//把数据库的数据渲染到模板上面
		ejs.renderFile('views/login.ejs',{
			msg:data,
			list:list
		},function(err,data){//渲染完成的回调函数
			res.end(data);
		})
	}else{
		var msg='这是注册页面，也是注册的路由';
		var h="<h2>这是一个h2</h2>"
		ejs.renderFile('views/register.ejs',{
			msg:msg,
			h:h
		},function(err,data){
			res.end(data);
		})
	}
}).listen(8001);
```

测试：http://localhost:8001/login   返回数据列表

测试：http://localhost:8001/register  注册页面

# 4、Get、Post

超文本传输协议（HTTP）的设计目的是保证客户端机器与服务器之间的通信。 在客户端和服务器之间进行请求-响应时，两种最常被用到的方法是：GET 和 POST。 

- GET - 从指定的资源请求数据。（一般用于获取数据）
- POST - 向指定的资源提交要被处理的数据。（一般用于提交数据）

## form表单

nodejs\09\views\form.ejs

```ejs
<body>
    <h2>登录</h2>

    <form action="/dologin" method="post">
        <input type="text" name="username"/>
        <br/>

        <input type="password" name="password"/>

        <input type="submit" value="登录"/>
        
    </form>
</body>
```

```js

//引入http模块
var http=require('http');

var url=require('url');

var ejs=require('ejs');

var fs=require('fs');

//路由:指的就是针对不同请求的 URL，处理不同的业务逻辑。
http.createServer(function(req,res){

	res.writeHead(200,{"Content-Type":"text/html;charset='utf-8'"});


	//获取get 还是post请求


	var method=req.method.toLowerCase();
	//console.log(method);

	var pathname=url.parse(req.url,true).pathname;


	if(pathname=='/login'){  /*显示登录页面*/


		ejs.renderFile('views/form.ejs',{

		},function(err,data){


			res.end(data);

		})


	}else if(pathname=='/dologin' &&method=='get'){  /*执行登录的操作*/


		//get获取数据
		console.log(url.parse(req.url,true).query);

		res.end('dologin');



	}else if(pathname=='/dologin' &&method=='post'){  /*执行登录的操作*/


		var postStr='';
		req.on('data',function(chunk){

			postStr+=chunk;
		})
		req.on('end',function(err,chunk){

			//res.end(postStr);
			console.log(postStr);

			fs.appendFile('login.txt',postStr+'\n',function(err){

				if(err){
					console.log(err);
					return;
				}
				console.log('写入数据成功');
			})
			res.end("<script>alert('登录成功');history.back();</script>")
		})
	}else{

		ejs.renderFile('views/index.ejs',{

		},function(err,data){
			res.end(data);
		})
	}

}).listen(8001);
```



获取GET传值： 

```js
var urlinfo=url.parse(req.url,true);
urlinfo.query();
```


获取POST传值： 

```js
var postData = ''; // 数据块接收中
req.on('data', function (postDataChunk) { 
    postData += postDataChunk; 
}); 
// 数据接收完毕，执行回调函数 
req.on('end', function () {
    try {
       postData = JSON.parse(postData); 
    } catch (e) {} 
    req.query = postData; 
    console.log(querystring.parse(postData)); 
});
```

## 登录日志

```js
fs.appendFile('login.txt',postStr+'\n',function(err){
    if(err){
        console.log(err);
        return;
    }
    console.log('写入数据成功');
})
```




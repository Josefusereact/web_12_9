# 模块化方式封装仿express框架的路由

# 一、回顾



上节课我们讲的手动写的路由发现都写到了一个文件`01router.js`上，代码很多.现在想一种办法把这些路由封装起来。把`01router.js`运行起来

```bash
nodemon 01router.js
```

访问：

http://localhost:8001/login

# 二、模块化方式封装路由

## 2.1准备

新建文件夹nodejs\10\model

新建文件nodejs\10\model\model.js

```js
var app={
    //路由函数
    login:function(req,res){
        res.end("login");
    },
    register:function(req, res){
        res.end("register");
    }
}
module.exports=app;//暴露出去
```

新建文件nodejs\10\02router.js

```js
var http=require('http');
var url=require('url');
var model=require('./model/model.js');

http.createServer(function(req,res){

    res.writeHead(200,{"Content-Type":"text/html;charset='utf-8'"});
    var pathname=url.parse(req.url).pathname.replace('/','');//pathname是要执行函数的名称，这里不要那个斜杠
    if(pathname!='favicon.ico') {

        try {
            model[pathname](req, res);
        } catch (err) {//访问不存在的出错访问home
            model['home'](req, res);
        }

    }
}).listen(8001);

```

测试：http://localhost:8001/login

## 2.2继续

nodejs\10\model\model.js

```js
var ejs = require('ejs');
var fs = require('fs');
var app = {
    /********login 处理***********/
    login: function (req, res) {
        ejs.renderFile('views/form.ejs', {}, function (err, data) {
            res.end(data);
        })
    },
    dologin: function (req, res) {
        var postStr = '';
        req.on('data', function (chunk) {
            postStr += chunk;
        })
        req.on('end', function (err, chunk) {
            fs.appendFile('login.txt', postStr + '\n', function (err) {
                if (err) {
                    console.log(err);
                    return;
                }
                console.log('写入数据成功');
            })
            res.end("<script>alert('登录成功');history.back();</script>")
        })
    },
    register: function (req, res) {
        console.log('register');
        res.end('register');
    }, 
    home: function (req, res) {
        console.log('home');
        res.end('home');
    }
}
module.exports = app;
```

# 三、封装仿Express路由

https://www.expressjs.com.cn/ 官网查看

https://www.expressjs.com.cn/starter/basic-routing.html  路由详解

## 3.1演示

nodejs\10\03demo.js  封装好的，对比之前的，更清晰的区分get或者post请求

## 3.2基础

要完成express框架，先理解给函数对象调用的基础知识，看看是怎么调用的

nodejs\10\04router_express.js

```js


var app=function(){

    console.log('app');
}

app.get=function(){
    console.log('app.get');
}
app.post=function(){
    console.log('app.post');
}


app.post() /*app.post*/

//
app()   /*app*/

```

## 3.3升级

如何处理请求的url路径

nodejs\10\05router_express.js

使用app对象的时候

```js
var G={};//声明一个对象，用于放app是否有login,register这样请求的处理函数名

var app=function(req,res){
    if(G['login']){
        G['login'](req,res);  /*执行注册的方法*/
    }
}

//定义一个get方法
app.get=function(string,callback){
    G[string]=callback;

    //注册方法
    //G['login']=function(req,res){
    //
    //}
}

//执行get方法
app.get('login',function(req,res){
    console.log('login'+req);
})


setTimeout(function(){
    app('req','res');
},1000);




```

## 3.4和http服务结合

把以上的代码和http服务结合起来使用



1.创建服务createServer中的回调函数换成了app, 把这个监听请求和响应的回调函数给app来做

2.注册login这个路由（方法）

3.只要有请求就会触发app方法

4.判断请求路径，做相应的跳转



nodejs\10\06router_express.js

```js
var http = require('http');

var url = require('url');
var G = {};

//*********************************定义方法开始*************************/
var app = function (req, res) {
    
    var pathname = url.parse(req.url).pathname;//返回的路径格式是/login  /register
    
    if (!pathname.endsWith('/')) {
        pathname = pathname + '/';
    }
    if (G[pathname]) {
        G[pathname](req, res);  /*执行注册的方法*/
    } else {
        res.end('no router');
    }
}

//定义一个get方法
app.get = function (string, callback) {
    if (!string.endsWith('/')) {
        string = string + '/';
    }
    if (!string.startsWith('/')) {
        string = '/' + string;

    }
    //    /login/
    G[string] = callback;
}
/******************************定义方法结束****************************************/
//只有有请求 就会触发app这个方法
http.createServer(app).listen(3000);

//注册login这个路由（方法）
app.get('login', function (req, res) {

    console.log('login');
    res.end('login');
})

app.get('register', function (req, res) {

    console.log('register');
    res.end('register');
})
```

## 3.5测试

http://localhost:3000    没有这个路由

http://localhost:3000/login   显示 login

# 四、对get、post请求封装

## 4.1....

新建nodejs\10\06router_express_module.js

```js
var http = require('http');

http.createServer(function(req, res){
    res.end('hello nodejs');
}).listen(3000);
```

## 4.2...

封装一个nodejs\10\model\express-route.js  按刚才的方法定义我们的那些东西

```js
//暴露的模块
var Server = function(){
    var app = function(req, res){

    }
    return app;
}
module.exports = Server();//调用这个方法
```

## 4.3 创建get方法

```js
var Server = function(){
    var app = function(req, res){

    }
    app.get = function(string, callback){

    }
    return app;
}
module.exports = Server();//直接调用这个方法返回app
```

为app.get方法添加内容，粘上面写过的代码

```js
app.get = function (string, callback) {
    if (!string.endsWith('/')) {
        string = string + '/';
    }
    if (!string.startsWith('/')) {
        string = '/' + string;
    }
    G[string] = callback;
}
```

这里的`G`添加进去

```js
var Server = function(){
    //定义G
    var G = this;
    var app = function(req, res){

    }
```

## 4.4  url处理

复制上步的代码到app里,引入url模块

`var url = require('url');`

```js
var app = function (req, res) {
    var pathname = url.parse(req.url).pathname;
    if (!pathname.endsWith('/')) {
        pathname = pathname + '/';
    }
    if (G[pathname]) {
        G[pathname](req, res);
    } else {
        res.end('no router');
    }
}
```

封装好了！！！

## 4.5引用封装好的模块

```js
var http = require('http');
var app =   require('./model/express-route-beike');
http.createServer(app).listen(3000);
```

添加路由

```js
var http = require('http');
var app =   require('./model/express-route-beike');
http.createServer(app).listen(3000);
//登录页面
app.get('/login',function(req,res){
    console.log('login');
    res.end('login');
})
```

## 4.6封装get和post

添加全局对象

```js
//处理get和post请求
this._get={};

this._post={};
```





添加post处理，在express-route.js中

注意这里G._post注册请求类型



```js
app.post=function(string,callback){
    if(!string.endsWith('/')){
        string=string+'/';
    }
    if(!string.startsWith('/')){
        string='/'+string;
    }
    G._post[string]=callback;
}
```

修改app.get函数, 一样也注册到G_get对象中

```js
app.get = function (string, callback) {
    if (!string.endsWith('/')) {
        string = string + '/';
    }
    if (!string.startsWith('/')) {
        string = '/' + string;
    }
    G._get[string]=callback;
}
```

获取请求类型

```js
//获取路由
var pathname = url.parse(req.url).pathname;
if (!pathname.endsWith('/')) {
    pathname = pathname + '/';
}
/******************获取请求方式******************************/
var method=req.method.toLowerCase();
```

修改请求路径

```js
 if (G['_'+method][pathname]) {
     if(method == 'post'){/**post方式的请求 */
         var postStr='';
         req.on('data',function(chunk){
             postStr+=chunk;
         })
         req.on('end',function(err,chunk) {
             req.body=postStr;  /*表示拿到post的值*/
             //G._post['dologin'](req,res)
             G['_'+method][pathname](req,res); /*执行方法*/
         })
     }else{/**get方式的请求 */
         G['_'+method][pathname](req, res);
     }
     // XXXXXXXX  不要G[pathname](req, res);
 } else {
     res.end('no router');
 }
```

验证一下

再添加一个路由处理

```js
app.get('/register',function(req,res){
    console.log('register');
    res.end('register');
})
```

http://localhost:3000    没有这个路由

http://localhost:3000/login   显示 login

http://localhost:3000/register   显示 register

## 4.7引入ejs

```js
//登录页面
app.get('/login',function(req,res){

    console.log('login');
    ejs.renderFile('views/form.ejs',{},function(err,data){

        res.end(data);
    })
})
```

这里面会出现乱码，需要设置请求头修改字符集，为重复调用，我们封装一个方法,在nodejs\10\model\express-route.js添加一个全局函数，在app函数的外面

```js
//封装方法改变res  绑定res.send()
function changeRes(res){

    res.send=function(data){

        res.writeHead(200,{"Content-Type":"text/html;charset=utf-8"});

        res.end(data);
    }
}
```

在app函数里调用这个方法，给res添加`send`函数

```js
var app = function (req, res) {
        
changeRes(res);
```

把之前的路由处理修改一下

```js
//登录页面
app.get('/login',function(req,res){
    console.log('login');
    ejs.renderFile('views/form.ejs',{},function(err,data){
        res.send(data);//<=========
    })
})
app.get('/register',function(req,res){

    console.log('register');

    res.send('register');//<=========
})
```

## 4.8登录处理

处理nodejs\10\views\form.ejs 的表单请求

```html
<form action="/dologin" method="post">
```

```js
//执行登录
app.post('/dologin',function(req,res){

    console.log(req.body);  /*获取post传过来的数据*/

    res.send("<script>alert('登录成功');history.back();</script>")
})
```

## 4.9首页处理

这里传了一个参数`msg`

```js
app.get('/',function(req,res){

    var msg='这是数据库的数据'

    ejs.renderFile('views/index.ejs',{msg:msg},function(err,data){

        res.send(data);
    })
})
```

完成了nodejs基础
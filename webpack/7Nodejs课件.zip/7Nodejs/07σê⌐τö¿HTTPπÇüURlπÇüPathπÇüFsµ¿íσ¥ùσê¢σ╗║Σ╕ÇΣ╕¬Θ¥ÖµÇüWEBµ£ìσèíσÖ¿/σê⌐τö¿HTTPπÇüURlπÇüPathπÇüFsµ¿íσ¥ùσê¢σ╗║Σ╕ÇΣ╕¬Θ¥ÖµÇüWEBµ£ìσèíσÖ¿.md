# 利用HTTP、URl、Path、Fs模块创建一个静态WEB服务器

# 1、Node.js 创建的第一个web应用

首先我们看一下开始讲的使用`http`模块创建的服务,简单的web服务器

1、引入http模块

```js
 var http = require("http");
```



2、创建服务器 接下来我们使用 http.createServer() 方法创建服务器，并使用 listen 方法绑定 8888 端口。 函数通过 request, response 参数来接收和响应数据。

```js
//1.引入http模块 var http=require('http');
//2.用http模块创建服务 
http.createServer(function(req,res){ 
    // 发送 HTTP 头部 
    // HTTP 状态值: 200 : OK 
    //设置 HTTP 头部，状态码是 200，文件类型是 html，字符集是 utf-8 
    res.writeHead(200,{"Content-Type":"text/html;charset=utf-8"}
                 ); 
    res.write('你好 nodejs'); 
    res.write('我是第一个nodejs程序'); 
    res.end(); /*结束响应*/ }
).listen(8001);
```

# 2、WEB服务器介绍

Web服务器一般指网站服务器，是指驻留于因特网上某种类型计算机的程序，可以向浏览器等Web客户端提供文档，也可以放置网站文件，让全世界浏览；可以放置数据文件，让全世界下载。目前最主流的三个Web服务器是Apache Nginx IIS。

# 3、Nodejs创建一个WEB服务器。

准备好一个static文件夹，这里是一个静态的网站

![image-20200823105016877](images\image-20200823105016877.png)

## 3.1目标

输入http://localhost:8001/index.html可以看到网页，输入任何文件，都可以访问

## 3.2如何

当输入资源的时候，网页的时候，nodejs如何返回这个页面呢？

1. 首先要先得到输入的内容
2. 过滤无效的请求
3. 读取文件
4. 读取到了就响应（res）这个文件

```js

//引入http模块
var http=require('http');
//fs模块
var fs=require('fs');
http.createServer(function(req,res){
	//http://localhost:8001/news.html    /news.html
	//http://localhost:8001/index.html    /index.html
	//css/dmb.bottom.css
	/**********第一步：得到URL   ****************/
	var pathname=req.url;
	if(pathname=='/'){
		pathname='/index.html'; /*默认加载的首页*/
	}
	/**********第二步：过滤请求favicon.ico*******/
	if(pathname!='/favicon.ico'){  
		console.log(pathname);
		//第三步：文件操作获取 static下面的index.html
		fs.readFile(__dirname+'/static/'+pathname,function(err,data){
			if(err){  /*么有这个文件*/
				console.log('404');
                /*简单的写是404字符，应该返回页面
                   fs.readFile('static/404.html',function(error,data404){
					if(error){
						console.log(error);
					}
					res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
					res.write(data404);
					res.end(); /*结束响应*/
				})*/
			}else{ /*返回这个文件*/
				res.writeHead(200,{"Content-Type":"text/html;charset='utf-8'"});
				res.write(data);
				res.end(); /*结束响应*/
			}
		})
	}
}).listen(8001);

```

以上实现了最简单的服务器

测试http://localhost:8001/login.html

http://localhost:8001/css/centerRight.css

为什么样式还没有显示出来？是不是应该是`text/css`?

![image-20200823111251687](images\image-20200823111251687.png)

# 4、继续完善

## 4.1请求文件类型

1. 得到文件的扩展名，导入`path`模块

2. 封装一下函数，通过扩展名返回MIME

   /model/getmime.js

   ```js
   exports.getMime=function(extname){
       switch (extname){
           case '.html':
               return 'text/html';
           case '.css':
               return 'text/css';
           case '.js':
               return 'text/javascript';
           default:
               return 'text/html';
       }
   
   }
   ```

   

3. 引用模块getmime

   ```js
   var mimeModel=require('./model/getmime.js');
   ```

   

4. 使用这个函数

      ```js
var mime=mimeModel.getMime(extname);
      ```



00services2.js

```js

//引入http模块
var http=require('http');
//fs模块
var fs=require('fs');
//path模块
var path=require('path');  /*nodejs自带的模块*/

var mimeModel=require('./model/getmime.js');

//console.log(mime.getMime('.css'));   //获取文件类型

http.createServer(function(req,res){
	var pathname=req.url;
	if(pathname=='/'){
		pathname='/index.html'; /*默认加载的首页*/
	}

	/***第一步：获取文件的后缀名***/
	var extname=path.extname(pathname);

	if(pathname!='/favicon.ico'){  /*过滤请求favicon.ico*/
		//console.log(pathname);
		//文件操作获取 static下面的index.html
		fs.readFile(__dirname+'/static/'+pathname,function(err,data){
			if(err){  /*么有这个文件*/
				console.log('404');
				fs.readFile(__dirname+'/static/404.html',function(error,data404){
					if(error){
						console.log(error);
					}
					res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
					res.write(data404);
					res.end(); /*结束响应*/
				})
			}else{ /*返回这个文件*/
				/*第四步：获取文件类型*/
				var mime=mimeModel.getMime(extname);  
				res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
				res.write(data);
				res.end(); /*结束响应*/
			}
		})
	}
}).listen(8001);
```

## 4.2加载数据

![image-20200823113129027](images\image-20200823113129027.png)

之前我们使用

```js
var pathname=req.url;
```

拿到的是`/json/all.json?7836384107568377`,不需要问号后面的参数 

修改成

```js
url.parse(req.url).pathname
```

完整代码

```js

//引入http模块
var http=require('http');

//fs模块

var fs=require('fs');

//path模块
var path=require('path');  /*nodejs自带的模块*/

//url模块

var url=require('url');


var mimeModel=require('./model/getmime.js');

//console.log(mime.getMime('.css'));   //获取文件类型

http.createServer(function(req,res){

	var pathname=url.parse(req.url).pathname;

	// console.log(pathname);

	if(pathname=='/'){
		pathname='/index.html'; /*默认加载的首页*/
	}
	//获取文件的后缀名
	var extname=path.extname(pathname);
	if(pathname!='/favicon.ico'){  /*过滤请求favicon.ico*/
		//console.log(pathname);
		//文件操作获取 static下面的index.html
		fs.readFile('static/'+pathname,function(err,data){
			if(err){  /*么有这个文件*/
				console.log('404');
				fs.readFile('static/404.html',function(error,data404){
					if(error){
						console.log(error);
					}
					res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
					res.write(data404);
					res.end(); /*结束响应*/
				})
			}else{ /*返回这个文件*/
				var mime=mimeModel.getMime(extname);  /*获取文件类型*/
				res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
				res.write(data);
				res.end(); /*结束响应*/
			}
		})
	}

}).listen(8001);
```

## 4.3 MIME全类型

图片虽然可以加载出来，但是图片类型的MIME不对,依然还是text/htm

准备一个文件nodejs\07\mime.json，文件中放的都是文件类型，共400多种文件类型

nodejs\07\model\getmimefromfile.js

这是的fs没声明是传进来的

```js

exports.getMime=function(fs,extname){  /*获取后缀名的方法*/
  //.html
    //console.log('1');  现不写，用于异步测试
    fs.readFile(__dirname+'/../mime.json',function(err,data){
        if(err){
            console.log(err,'mime.json文件不存在');
            return false;
        }
        // console.log(data.toString());
        var Mimes=JSON.parse(data.toString());
        console.log(Mimes[extname]);
        //console.log('2');现不写，用于异步测试
        return Mimes[extname] || 'text/html';

    })
   // console.log('3');现不写，用于异步测试
}
```

测试：

```js
 var fs=require('fs');
var mimeModel=require('./model/getmimefromfile.js');
mimeModel.getMime(fs, '.css');
```



以上的方式是通过异步的方式得到MIME，输入一些console.log,,1,2,3 , 发现返回的内容太早

现在使用同步的方式

getmimefromfile.js

```js

exports.getMime=function(fs,extname){  /*获取后缀名的方法*/
    //把读取数据改成同步
    var data=fs.readFileSync('./mime.json');
    //data.toString() 转换成json字符串
    var Mimes=JSON.parse(data.toString());  /*把json字符串转换成json对象*/
    return Mimes[extname] || 'text/html';
}
```



# 5.完整代码

```js

//引入http模块
var http=require('http');

//fs模块

var fs=require('fs');

//path模块
var path=require('path');  /*nodejs自带的模块*/

//url模块

var url=require('url');

//引入扩展名的方法是在文件里面获取到的。

var mimeModel=require('./model/getmimefromfile.js');

//console.log(mimeModel.getMime('.css'));   //获取文件类型

http.createServer(function(req,res){


	var pathname=url.parse(req.url).pathname;

	console.log(pathname);

	if(pathname=='/'){
		pathname='/index.html'; /*默认加载的首页*/
	}

	//获取文件的后缀名
	var extname=path.extname(pathname);

	if(pathname!='/favicon.ico'){  /*过滤请求favicon.ico*/
		//console.log(pathname);
		//文件操作获取 static下面的index.html

		fs.readFile('static/'+pathname,function(err,data){

			if(err){  /*么有这个文件*/

				console.log('404');

				fs.readFile('static/404.html',function(error,data404){
					if(error){
						console.log(error);
					}
					res.writeHead(404,{"Content-Type":"text/html;charset='utf-8'"});
					res.write(data404);
					res.end(); /*结束响应*/
				})

			}else{ /*返回这个文件*/

				var mime=mimeModel.getMime(fs,extname);  /*获取文件类型*/
				res.writeHead(200,{"Content-Type":""+mime+";charset='utf-8'"});
				res.write(data);
				res.end(); /*结束响应*/
			}
		})
	}
}).listen(8002);
```


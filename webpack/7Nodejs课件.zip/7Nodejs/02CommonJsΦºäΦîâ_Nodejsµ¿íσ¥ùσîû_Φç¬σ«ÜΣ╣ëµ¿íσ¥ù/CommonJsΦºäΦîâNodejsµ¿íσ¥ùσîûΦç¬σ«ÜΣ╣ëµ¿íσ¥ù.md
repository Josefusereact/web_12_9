# CommonJs规范_Nodejs模块化_自定义模块

# 一、什么是CommonJs？

 		JavaScript是一个强大面向对象语言，它有很多快速高效的解释器。然而， JavaScript标准定义的API是为了构建基于浏览器的应用程序。并没有制定一个用于更广泛的应用程序的标准库。CommonJS规范的提出,主要是为了弥补当前JavaScript没有标准的缺陷。它的终极目标就是：提供一个类似Python和Java语言的标准库,而不只是停留在小脚本程序的阶段。用CommonJS API编写出的应用，不仅可以利用 JavaScript开发客户端应用，而且还可以编写以下应用。

## 1.1模块化的思想

模块化是一种设计思想，利用模块化可以把一个非常复杂的系统结构细化到具体的功能点，每个功能点看做一个模块，然后通过某种规则把这些小的模块组合到一起，构成模块化系统。

### 1.1.1 模块化概念

![image-20200204140247784](文档中的图片/image-20200204140247784.png)

模块化手机分为多个模块，当某个模块坏掉了都可以单独替换，从生产角度，模块化是一种生产方式，这种生产方式体现了两个特点

​		1.**生产效率高**--灵活架构，焦点分离、多人协作互不干扰、方便模块间组合、分解，方便代码重用，对于别人开发好的模块功能可以直接拿过来使用，不需要重复开发类似的功能。

​		2.**维护成本低**--可分单元测试、方便单个模块功能调试、升级。软件开发的周期中，由于需求经常发生变化，最长的阶段并不是开发阶段，而是维护阶段，使用模块化开发的方式更容易维护。

​		在程序中也有很多模块化的例子，例如日期模块（Date）、数学计算模块（Math）、日志模块、登录认证模块、报表展示模块等，所有模块组成一个程序软件系统，对于程序我们可以说，一切皆模块！

​		![image-20200204143023135](文档中的图片/image-20200204143023135.png)

### 1.1.2 为什么要模块化开发

​		非模块化开发遇到哪些问题？

​		1.命名冲突，通过示例代码，恼人的命名冲突

```javascript
var foo = 'bar';
var foo = 'baz';
```

​		![image-20200204145141982](文档中的图片/image-20200204145141982.png)

​		2.文件依赖，通过示例代码，繁琐的文件依赖

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <script src="./ccc.js"></script>
    <script src="a.js"></script>
    <script src="b.js"></script>
    <script src="c.js"></script>
    <script src="d.js"></script>
    <script src="./aaa.js"></script>
</body>
</html>
```

![image-20200204145158742](文档中的图片/image-20200204145158742.png)

## 1.2模块化编程的演变

### 1.2.1 全局函数

​		用JavaScript实现一个简易计算器

![image-20200204150151870](文档中的图片/image-20200204150151870.png)

​		查看代码：

​		demo1-1.html

```html

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>模块化开发演变 - 全局函数</title>
</head>
<body>
  <input type="text" id="x">
  <select name="" id="opt">
    <option value="0">+</option>
    <option value="1">-</option>
    <option value="2">*</option>
    <option value="3">/</option>
  </select>
  <input type="text" id="y">
  <button id="cal">=</button>
  <input type="text" id="result">
  <script>
       //定义用于计算的函数
        function add(x, y) {
          return parseInt(x) + parseInt(y);
        }

        function subtract(x, y) {
          return parseInt(x) - parseInt(y);
        }

        function multiply(x, y) {
          return parseInt(x) * parseInt(y);
        }

        function divide(x, y) {
          return parseInt(x) / parseInt(y);
        }
       // 获取所有的 dom 元素
       var oX = document.getElementById('x');//第一个数值
       var oY = document.getElementById('y');//第二个数值
       var oOpt = document.getElementById('opt');//获取运算符
       var oCal = document.getElementById('cal');//获取等号按钮
       var oResult = document.getElementById('result')//结果数值
//为等号按钮添加单击事件，当按钮被点击时调用此方法
  oCal.addEventListener('click', function() {
    var x = oX.value.trim();
    var y = oY.value.trim();
    var opt = oOpt.value;

    var result = 0;
    switch (opt) {
      case '0':
        result = add(x, y);//加
        break;
      case '1':
        result = subtract(x, y);//减
        break;
      case '2':
        result = multiply(x, y);//乘
        break;
      case '3':
        result = divide(x, y);//除
        break;
    }
    oResult.value = result;

  })
  </script>
</body>
</html>
```



​		全局函数这种编程方式很常见，但是不可取，因为所有的变量和函数都暴露在全局，无法保证全局变量不与其他模块的变量发生冲突，污染了全局变量，另外，全局函数形成的模块成员之间看不出直接关系

### 1.2.2 对象命名空间

```javascript
 /**
   * 对象命名空间
   * 只是从理论意义上减少了命名冲突的问题，但是命名冲突还是存在
   */
  var calculator = {};
   //加法
  calculator.add = function(x, y) {
    return parseInt(x) + parseInt(y);
  }
  //减法
  calculator.subtract = function(x, y) {
    return parseInt(x) - parseInt(y);
  }
  //乘法
  calculator.multiply = function(x, y) {
    return parseInt(x) * parseInt(y);
  }
  //除法
  calculator.divide = function(x, y) {
    return parseInt(x) / parseInt(y);
  }
```

​		从代码层面可以知道哪些函数属于同一个模块，用于计算的四个函数的命名冲突问题也解决了，但是如果需要在定义一个名称为calculator的命名空间还是会报错，由此可见，只是从理论意义上减少了命名冲突的问题，但是命名冲突还是存在，而且这种方式是内部成员的状态可以随意被外部改写，不安全。

### 1.2.3 函数的作用域(闭包)

​		javascript中通过封装函数的私有控件可以让一些属性和方法私有化，也就是所谓的闭包。可以通过匿名自执行函数，进行私有变量隔离。

```javascript
  /**
   * 对象命名空间
   * 只是从理论意义上减少了命名冲突的问题，但是命名冲突还是存在
   * 利用匿名自执行函数形成的封闭的函数作用域空间，达到私有化的目的
   */

  var calculator =  (function () {

    function add(x, y) {
      return parseInt(x) + parseInt(y);
    }

    function subtract(x, y) {
      return parseInt(x) - parseInt(y);
    }

    function multiply(x, y) {
      return parseInt(x) * parseInt(y);
    }

    function divide(x, y) {
      return parseInt(x) / parseInt(y);
    }

    return {
      add: add,
      subtract: subtract,
      multiply: multiply,
      divide: divide
    }
  })();
```

​		用于计算的四个方法被封装到了立即执行匿名函数中，如果不添加返回值，外部是访问不到的，添加返回值后后在全局可以通过“匿名函数.函数名()”的方式进行调用。这样有效的公开了公有方法，并且可以隐藏一些私有是属性和元素，私有空间的函数和变量也不会影响全局作用域，可见这种方式是最理想的方式。大部分第三方库都使用了这种形式，例如jQuery

### 1.2.4 维护和扩展

​		新需求在计算器案例中添加一个取余的方法

​		方法一：在匿名函数中添加一个方法，并且返回

```javascript
var calculator =  (function () {

    function add(x, y) {
      return parseInt(x) + parseInt(y);
    }

    function subtract(x, y) {
      return parseInt(x) - parseInt(y);
    }

    function multiply(x, y) {
      return parseInt(x) * parseInt(y);
    }

    function divide(x, y) {
      return parseInt(x) / parseInt(y);
    }
		function mod(x,  y){
      return parseInt(x) % parseInt(y);
    }
    return {
      add: add,
      subtract: subtract,
      multiply: multiply,
      divide: divide,
      mod: mod;
    }
  })();
```

如果这个计算器模块由第三方库提供，成千上万行代码，难道也要修改源代码吗？

当我们要对这个模块进行扩展和维护的时候，或者这个模块存有第三方依赖的时候，可以通过参数的形式将原来的模块和第三方库传递进去。

```javascript
       //传递参数cal
    var calculator = (function(cal) {
        //加法
        function add(x, y) {
            return parseInt(x) + parseInt(y);
        }
        // 减法
        function subtract(x, y) {
            return parseInt(x) - parseInt(y);
        }
        //乘法
        function multiply(x, y) {
            return parseInt(x) * parseInt(y);
        }
        //除法
        function divide(x, y) {
            return parseInt(x) / parseInt(y);
        }
        cal.add = add;
        cal.subtract = subtract;
        cal.multiply = multiply;
        cal.divide = divide;

        return cal;
    })(calculator || {});

    // 从代码上来看：下面的 calculator 已经把上面的 calculator 给覆盖掉了
    // 注意：在进行扩展的时候，优先查找要扩展的对象是否已存在
    // 如果已存在，就使用已经存在的
    // 如果不存在，就创建一个新的
    // 最大的好处：加载的时候不用考虑顺序了
    var calculator = (function(cal) {
        //取余方法
        cal.mod = function(x, y) {
            return x % y;
        }
        return cal;

    })(calculator || {});

    // 获取所有的 dom 元素
    var oX = document.getElementById('x');
    var oY = document.getElementById('y');
    var oOpt = document.getElementById('opt');
    var oCal = document.getElementById('cal');
    var oResult = document.getElementById('result');
    //为等号按钮添加单击事件，当按钮被点击时调用此方法
    oCal.addEventListener('click', function() {
        var x = oX.value.trim();
        var y = oY.value.trim();
        var opt = oOpt.value;
        var result = 0;
        switch (opt) {
            case '0':
                result = calculator.add(x, y);
                break;
            case '1':
                result = calculator.subtract(x, y);
                break;
            case '2':
                result = calculator.multiply(x, y);
                break;
            case '3':
                result = calculator.divide(x, y);
                break;
            case '4':
                result = calculator.mod(x, y);
                break;
        }
        oResult.value = result;
    })
```

上述代码，第二行代码用匿名函数中传递cal作为参数，该参数可以看作匿名函数本身，第25行代码"calculator||{}"的意思是，当扩展该模块时，判断calculator函数是否存在，如果存在使用已经存在的，如果不存在 就重新创建，这样做的好处是在加载时不需要考虑顺序。32~39行用于添加取余的方法，第67行用于调用取余的方法。





# 二、模块化 ---重写计算器案例

add.js

```javascript
//加法
module.exports = function (x, y) {
  return parseInt(x) + parseInt(y)
}
```



subtract.js

```javascript
//减法
module.exports = function (x, y) {
  return parseInt(x) - parseInt(y)
}
```



multiply.js

```javascript
//乘法
module.exports = function (x, y) {
  return parseInt(x) * parseInt(y)
}
```



divide.js

```javascript
module.exports = function (x, y) {
  return parseInt(x) / parseInt(y)
}

```



index.js

```javascript
module.exports = {
  add: require('./add'),
  subtract: require('./subtract'),
  multiply: require('./multiply'),
  divide: require('./divide')
}
```

testCal.js

```javascript
//测试计算器功能
var cal = require('./index');
//在终端输出计算结果
console.log(cal.add(1, 2)); // => 3
console.log(cal.subtract(1, 2)) ;// => -1
console.log(cal.multiply(1, 2)); // => 2
console.log(cal.divide(1, 2)) ;// => 0.5
```

# 三、require()的模块加载规则

require()函数的加载顺序

​    1.核心模块

​    2.上node_modules文件夹找js文件

​    3.上node_modules文件夹里文件夹，这个文件夹有package.json

​    4.在工程文件夹上面node_modules里找

## 1.文件模块

​		使用require()方法加载文件模块时，需要使用两种模块标识：

* 以 “/” 开头的模块标识，指向当前文件所属盘符的根路径。

* 以“./” 或 `../` 开头的相对路径模块标识。

  ```javascript
  require('/example.js');//如果当前文件在c盘，将加载c:\example.js
  require('./example.js');
  require('../example.js');
  ```

  上面三行可以省略文件的扩展名“.js”,  nodejs会尝试为文件 名添加 `.js`     ,  `.json` ,   `.node`进行查找 

## 2.核心模块

​		核心模块也叫内置模块可以看作是nodejs的心脏，它由一些精简而高效的库组成，为nodejs提供了基本的API。主要内容包括。

- 全局对象；

- 常用工具；

- 事件机制；

- 文件系统访问；

- HTTP 服务器与客户端。

  ​	由于Node.js的模块机制，这些Node.js中内置的核心模块被编译成二进制文件，保存在Node.js源码的lib文件夹下，在本质上也是文件模块，但是在加载方式上与文件模块有所区别。

   核心模块标识是唯一的，并且不以 `./` 或 `../` 或 `/` 开头，使用require()加载核心模块的语法如下所示。

  require('模块标识');

  ```javascript
  // 核心模块就是一个固定标识
  // 如果写错，就无法加载
  var os = require('os');
  //输出CPU信息
  console.log(os.cpus());
  ```

## 3 模块的缓存

​		在模块加载过程中，对于多次使用同一模块标识加载模块的情况，Node.js只会加载一次，这是由于第一次加载某个模块时，Node.js会缓存该模块，再次加载时将从缓存中获取。所有缓存的模块保存在 `require.cache` 中，可以手动的删除模块缓存。

​		foo.js

```javascript
console.log("foo模块被加载了");
```

​		demo2-8.js

```javascript
// 对于同一个模块标识，node 在第一次加载完成之后就会缓存该模块
// 下次继续加载该模块的时候，直接从缓存中获取
require('./foo');
require('./foo');
require('./foo');
require('./foo');
```

![image-20200205194726571](文档中的图片/image-20200205194726571.png)

只输出一行“foo模块被加载了”

为foo.js添加一行代码：

```javascript
delete require.cache[module.filename] ;
```

在实际开发中有些时候开发者并不希望加载的模块被缓存。









# 四、Nodejs中的模块化

Node应用由模块组成，采用CommonJS模块规范。给我们提供了一大堆的模块，让我们去调用



## 4.1在Node中，模块分为两类:

1. 一类是Node提供的模块, 称为**核心模块**。
2. 一类是用户编写的模块，称为**文件模块**。

-  核心模块部分在Node源代码的编译过程中，编译进了二进制执行文件。在Node进程启动时，部分核心模块就被直接加载进内存中，所以这部分核心模块引入时，文件定位和编译执行这两个步骤可以省略掉，并且在路径分析中优先判断，所以它的加载速度是最快的。如：**HTTP**模块 、**URL**模块、**Fs**模块都是nodejs内置的核心模块，可以直接引入使用。 
- 文件模块则是在运行时动态加载，需要完整的路径分析、文件定位、编译执行过程、速度相比核心模块稍微慢一些，但是用的非常多。这些模块需要我们自己定义。接下来我们看一下nodejs中的自定义模块。

## 4.2CommonJS（Nodejs）中自定义模块的规定：

1. 我们可以把公共的功能抽离成为一个单独的 js 文件作为一个模块，默认情况下面这个模块里面的方法或者属性，外面是没法访问的。如果要让外部可以访问模块里面的方法或者属性，就必须在模块里面通过 exports 或者module.exports暴露属性或者方法。 

2. 在需要使用这些模块的文件中，通过require函数的方式引入这个模块。这个时候就可以使用模块里面暴露的属性和方法。

![image-20200822184043729](images\image-20200822184043729.png)

## 2.3定义使用模块：

### 2.3.1例一

commonjs01.js

```js
var http=require('http');
var config=require('./config.js');//需要一个模块,这里是自定义模块所以需要写路径，表示当前路径
var app=http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type":"text/html;charset=utf-8"});
    res.write('你好 nodejs');
    console.log(config.str);
    res.end();
})
app.listen(8002,'127.0.0.1');
```

config.js

```js
var str='this is config';
exports.str=str;  /*暴露模块*/
//module.exports=str;
```

### 2.3.2例二

tools.js

```js
var tools={
    add:function(x,y){
        return x+y;
    },
    sayHello:function(){
        return '你好 nodejs'
    }
}
//exports.tools=tools;
module.exports=tools;
```

commonjs02.js

```js
var tools=require('./tools.js');
console.log(tools.add(1,2));
console.log(tools.sayHello());
```

exports 和 module.exports 的区别，module.exports 指向新的对象时，exports 断开了与 module.exports 的引用，那么通过 exports = module.exports 让 exports 重新指向 module.exports 即可。也可以写成这样

```js
exports = module.exports = somethings
```

### 2.3.3例三

commonjs03.js

省略了扩展名js

```js
var tools=require('./tools');   /*省略.js也是可以的*/
console.log(tools.add(1,2));
console.log(tools.sayHello());
```

### 2.3.4例四

新建文件夹`node_modules`

新建`nodejs\02\node_modules\foo.js`

```js
var str='this is foo.js 在 node_modules';
exports.str=str;  /*暴露模块*/
//module.exports=str;
```

commonjs04.js

foo默认在目录下面没有，没有的话nodejs会在node_modules里面找这个模块

```js
var foo=require('foo');
console.log(foo.str);
```

### 2.3.5例五

新建`nodejs\02\node_modules\bar\bar.js`

```js
var str='this is bar下面的bar.js 在 node_modules';
exports.str=str;  /*暴露模块*/
//module.exports=str;
```



commonjs05.js

```js
//var bar=require('bar/bar.js');
var bar=require('bar/bar');

/*bar默认在目录下面没有，没有的话nodejs会在node_modules里面找这个模块 */

console.log(bar.str);
```

> 想实现  直接通过  var bar=require('bar');

### 2.3.6例六

新建nodejs\02\node_modules\nav文件夹

新建nodejs\02\node_modules\nav\nav.js文件

```js
var str='this is nav下面的nav.js   在 node_modules';

exports.str=str;  /*暴露模块*/
//module.exports=str;
```

nodejs\02\commonjs06.js

```js
var nav=require('nav');
console.log(nav.str);
```

这样是找不到的,程序会出错

需要把nav文件夹创建成一个模块，这就是node模块的规范。需要使用npm 安装的模块就是这样引入的。



## 三、创建模块

npm init  -y       进入这个目录运行这个命令 

生成package.json   简单看一下，有一个入口文件nav.js

查找原理：

nav 在根目录不存在，去node_modules ，找到了nav文件夹。 

nav文件夹下面有package.json ，找 package.json 入口文件 "main": "nav.js"


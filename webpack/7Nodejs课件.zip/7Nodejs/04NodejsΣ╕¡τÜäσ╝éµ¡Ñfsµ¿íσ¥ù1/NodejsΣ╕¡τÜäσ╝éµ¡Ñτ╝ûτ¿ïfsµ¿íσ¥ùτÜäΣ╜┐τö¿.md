# 一、异步编程

​		JavaScript的执行环境单线程。单线程一次只能完成一件任务，如果有多个任务，就需要等待前面一个任务完成，再执行后面的一个任务。常见的浏览器无响应往往就是因为某一段JS代码长时间运行，例如死循环，导致其他任务无法执行，整个页面无法继续加载造成的。

![image-20200206095600949](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200206095600949.png)

​		为了解决单线程阻塞，Node.js中加入了异步编程模块。异步编程模型保证了Node.js快速响应。

## 1.同步和异步

### 1.1同步的概念

​		如果每件事情按照顺序依次进行就是同步。 举例： 小明是一个勤奋的孩子，他每天起得很早，起床后要背单词、吃早餐、然后去上学，如果每一件事情按照顺序依次进行就是同步。

​		![image-20200206100307325](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200206100307325.png)



用代码来表达：

```javascript
console.log('起床');
console.log('背单词');
//吃早餐
function eatBreakfast() {
    console.log('早餐吃完了');
}
eatBreakfast();
console.log('去上学');
```

### 1.2异步的概念

​		如果多件事情可以同时进行即异步。小明没有定闹钟，晚起床半个小时，背完单词后，带着早餐一边吃一边去上学，执行流程：

![image-20200206100912512](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200206100912512.png)

小明比之前节省了时间

```javascript
console.log('起床');

console.log('背单词');
function eatBreakfast() {
    console.log('开始吃早餐了');
    // setTimeout 执行的时候，不会阻塞后面代码的继续执行
    setTimeout(function () {
        console.log('早餐吃完了');
    }, 0);
}
eatBreakfast()
console.log('去上学');
```

## 2. 回调函数

​		回调函数是指函数可以被传递到另一个函数中，然后被调用的形式。这样的“回调函数”在nodejs中到处被使用，典型的应用就是异步函数地异常处理。下面通过代码的演示来学习回调函数的作用及使用。

#### 1.同步代码中使用try...catch处理异常

​		同步代码在处理异常上和异步代码也是有区别的

```javascript
/**
 * 同步代码处理异常
 */
function parseJsonStrToObj(str) {
    return JSON.parse(str)
}
// 对于同步代码，我们可以使用 try-catch 来捕获代码执行可能出现的异常
try {
    var obj = parseJsonStrToObj('foo')
    console.log(obj)
} catch (e) {
    console.log('转换失败了')

}

```

由于foo不是合法的JSON格式，错误信息被输出了

#### 2.异步代码无法使用try...catch处理异常

```javascript
function parseJsonStrToObj(str) {
    setTimeout(function() {
        return JSON.parse(str);
    }, 0);
}
//对于异步代码的执行来说，try-catch 是无法捕获异步代码中出现的异常的
try {
    var obj = parseJsonStrToObj('foo');
    console.log('执行结果是：' + obj);
} catch (e) {
    console.log('转换失败了');
}
```

![image-20200206103450579](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200206103450579.png)

第一行parseJsonStrToObj()函数的返回值是undefined,所以第8行obj对象的值也是undefined,最终代码会在第3行的位置报错，由此可以看出，使用try...catch不能捕获setTimeout函数中出现的异常。

#### 3.使用回调函数接收异步代码的执行结果

如果把try...catch写在setTimeout函数中真正执行报错的地方，是否可以实现呢？

```javascript
/**
 * try-catch写在异步代码中
 */
function parseJsonStrToObj(str) {
    setTimeout(function() {
        try{
            return JSON.parse(str);
        }catch(e){
            console.log('转换失败了');
        }
    }, 0);
}
//调用方法输出结果
var obj = parseJsonStrToObj('foo');
console.log('执行结果是：' + obj);

```

第7行调用JSON.parse()方法后，会有一个返回值，但是当前的写法无法接收到这个返回值

![image-20200206104537538](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200206104537538.png)

#### 4.回调函数

​		为了解决上述问题，异步编程中提出了回调函数的设计，可以使用回调函数来接收异步代码执行的处理结果。

​		回调函数即当我们使用异步代码去做一件事时，不能预测这件事什么时候做完，其他的事情还在继续，这时我们给异步代码准备一个包裹，当异步代码有了执行结果时可以将结果放到这个包裹里，我们需要在哪里使用这个结果就从包裹取出。

​		在回调函数的设计 中有3个约定：

​		（1）函数名称通常为callback,在封装异步执行代码的时候，优先把 callback作为函数的最后一个参数出现，语法如下所示：

```javascript
function 函数名(arg1,arg2,callback){
  
}
```

 		（2）把代码中出现的错误作为 callback 回调函数的第一个参数进行传递，语法如下所示：

```javascript
callback(err,result);
```

 		（3）把真正的返回的结果数据，传递给 callback 的第二个参数。语法如下所示：

```javascript
callback(err,result);
```

下面解决上述错误问题接收返回值的问题：

```javascript
//通过回调函数来接收异步代码执行的处理结果
function parseJsonStrToObj(str,callback) {
    setTimeout(function() {
        try {
            var obj = JSON.parse(str);
            callback(null, obj);
        } catch (e) {
            callback(e, null);
        }
    }, 0);
}
/*注意区分错误信息和正确的数据信息
*/
parseJsonStrToObj('{"foo":"bar"}',function (err, result) {
    if (err) {
        return console.log('转换失败了');
    }
    console.log('数据转换成功，没有问题可以直接使用了：' + result);
});
```

上述代码，第2行parseJsonStrToObj()函数的第二个参数为回调函数，该函数在第14行进行调用，回调函数中第一个参数err为错误信息，第二个参数result为返回数据，在调用异步API时，优先判断回调函数中的第一个参数err对象是否为空，用以确定在异步代码执行的过程中，是否发生了异常。

#### 5.理解异步编程的“事件驱动”思路

​		在异步编程中，当异步函数执行时，不确定何时执行完毕，回调函数会被压入到一个事件循环(Event Loop)的队列，然后接着往下执行其他代码，直到异步函数执行完成后，才会开始处理事件循环，调用相应的回调函数。这个事件循环队列是一个先进先出的队列，这说明回调是按照它们被加入队列的顺序执行的。

# 二、Nodejs中的fs模块的使用



首先引用fs模块

```js
var fs=require('fs');
```



## 1.fs.stat 检测是文件还是目录

```js
fs.stat('html',function(err,stats){
 if(err){
   console.log(err);

   return false;
 }

 console.log('文件：'+stats.isFile());
 console.log('目录：'+stats.isDirectory());

})
```

```js
//ES6的写法
fs.stat('hello.js', (error, stats) =>{ 
    	if(error){ console.log(error) } 
    	else { console.log(stats) 
              console.log(`文件：${stats.isFile()}`) 
              console.log(`目录：${stats.isDirectory()}`) 
             } 
})
```















## 2.fs.mkdir 创建目录



 接收参数：

 path      将创建的目录路径

 mode     目录权限（读写权限），默认0777

 callback   回调，传递异常参数err

```js
fs.mkdir('css', function (err) {
    if (err) {
        console.log(err);
        return false;

    }
    console.log('创建目录成功');
})
```



## 3.fs.writeFile 创建写入文件



filename   (String)      文件名称

data    (String | Buffer)  将要写入的内容，可以使字符串 或 buffer数据。

options    (Object)      option数组对象，包含：

· encoding  (string)      可选值，默认 ‘utf8′，当data使buffer时，该值应该为 ignored。

· mode     (Number)    文件读写权限，默认值 438

· flag      (String)      默认值 ‘w'

callback {Function} 回调，传递一个异常参数err。

```js
fs.writeFile('t.txt', '你好nodejs 覆盖', 'utf8', function (err) {
    if (err) {
        console.log(err);
        return false;

    }
    console.log('写入成功');

})
```

注意已经如果文件已经存在，它会覆盖

## 4.fs.appendFile 追加文件

```js
fs.appendFile('t1.txt', '这是写入的内容', function (err) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log('写入成功');

})
```



## 5.fs.readFile 读取文件



```js
fs.readFile('t1.txt', function (err, data) {
    if (err) {
        console.log(err);
        return false;
    }
    //console.log(data);//这里会输入16进制的内容
    //通过调用toString得到内容
    console.log(data.toString());
})
```

## 6.fs.readdir读取目录 

把目录下面的文件和文件夹都获取到。拿到一个文件夹下面的所有目录

```js
fs.readdir('html', function (err, data) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log(data);
})
```



## 7.fs.rename 重命名

### 1.改名 

```js
fs.rename('html/index.html', 'html/news.html', function (err) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log('修改名字成功');
})
```

### 2.剪切文件

```js
fs.rename('html/css/basic.css', 'html/style.css', function (err) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log('剪切成功');

})
```



##  8.fs.rmdir 删除目录



```js
fs.rmdir(__dirname+'/t', function (err) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log('删除目录成功');

})
```



### 这个方法只能删除目录

// ENOENT: no such file or directory, rmdir   rmdir 

```js
fs.rmdir('index.txt', function (err) {
    if (err) {
        console.log(err);
        return false;
    }
    console.log('删除目录成功');

})
```

## 9.fs.unlink删除文件



```js
fs.unlink('index.txt',function(err){
	if(err){
		console.log(err);
		return false;
   }
   console.log('删除文件成功');

})
```






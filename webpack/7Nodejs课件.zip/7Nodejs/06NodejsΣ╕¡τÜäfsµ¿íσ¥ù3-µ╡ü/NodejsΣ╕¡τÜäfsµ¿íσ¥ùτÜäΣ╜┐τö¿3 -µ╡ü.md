# Nodejs中的fs模块的使用3 -流

# Node.js中处理数据I/O

## 学习目标

1. 了解什么Buffer缓冲区 

2. 了解二进制数据和乱码

3. 熟悉缓冲区数据的读写

4. 了解什么是文件流

5. 掌握可读流和可写流
6. 掌握使用pipe处理大文件

JavaScript中对于字符串的操作十分便捷，不存在二进制数据类型，这种对字符串的简单操作和DOM操作基本上已经可以满足前端工程需求，但Node.js中很多时候需要处理文件和网络I/O，就需要处理大量的二进制数据，这些操作需要Node.js中的数据处理进行支持，其中包括数据的缓冲区Buffer和Stream文件流等，本章将针对Node.js中的数据处理进行详细的讲解。

## 一、Buffer缓冲区

Buffer 类是随 Node.js 内核一起发布的核心库，用于支持I/O（输入/输出）操作中移动的数据处理， Buffer类为nodejs带来了一种存储原始数据的方法，该方法用来在内存中创建一个专门存放二进制数据的缓冲区。也就是说在内存中预留了一定的存储空间，用来暂时保存输入或者输出的数据，这样就Node.js能够处理二进制数据了。

### 1.1二进制数据和乱码

​		什么是二进制？

​		我们知道英文中又26个字母，可以组成不同的单词，计算机的语言叫做二进制，计算机语言中的“单词”可以理解为二进制数据，这些“单词”由两个“字母”组成，即0和1，二进制数据可以翻译为我们能够识别的语言，例如小写字母a在Windows系统中的二进制数据就是“01100001”，每一个二进制位就是0和1的两种状态，它的基数为2，进位规则是“逢二进一”借位规则是“借一当二”，由18世纪德国数理哲学大师[莱布尼兹](https://www.baidu.com/s?wd=莱布尼兹&tn=44039180_cpr&fenlei=mv6quAkxTZn0IZRqIHckPjm4nH00T1Y3m1-Buyubn1T4ryPBm1m10ZwV5Hcvrjm3rH6sPfKWUMw85HfYnjn4nH6sgvPsT6KdThsqpZwYTjCEQLGCpyw9Uz4Bmy-bIi4WUvYETgN-TLwGUv3En1fvPW6vn1n3)发现，当前的计算机系统使用的基本上是二进制系统。

​		![image-20200208174657360](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208174657360.png)

​		由于计算机只能识别二进制数据，而我们人类很难看懂“1010”代表什么，因此，需要将二进制数据转换为我们能够方便识别的字符，这时就需要设置字符编码，通过字符编码找到相应的字符集进行“翻译”，这个字符集就像一本字典， Window系统最原始的的字符编码就是ASCII，它支持英文中常用的字母、数字和标点符号等与二进制数据之间的转换。

​		![image-20200208174930175](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208174930175.png)

​		同时清空提供八进制、十进制和十六进制的对应编码，各种编码都可以相互转换。

​		使用计算器来演示二进制数据与十进制等的转换：

​		![image-20200208175602738](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208175602738.png)

​		上图可以看到二进制、八进制、十进制、十六进制等选项，当前选中为二进制，只能使用按钮0或者按钮1，在计算器输入二进制数据“1100001”，单击十进制单选按钮，可以转换为十进制数据“97”，在ASCII码表中，二进制“1100001”和十进制的“97”，都对应小写字母“a”。

![image-20200208180704140](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208180704140.png)

![image-20200208180147246](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208180147246.png)

​		随着计算机的不断发展，计算机进入了全界的各个国家，这些国家使用的语言不一致，ASCII字符集已经不能满足需求，所以各个国家针对自己的语言制定了不同的字符集。每个字符集包含的字符个数不同，当前常用的字符集：ASCII字符集、GB2312字符集、BIG5字符集、 GB18030字符集、Unicode字符集等。UTF-8（8-bit Unicode Transformation Format）是一种针对Unicode的可变长度字符编码，包含了简体和繁体的中文字符，能正确显示多种语言，所以在出现乱码时，我们一般建议使用UTF-8编码。

​		二进制数据和乱码有着密不可分的关系，乱码是指计算机二进制数据在转换字符的过程中，使用了不合适的字符集，而造成部分或所有字符无法被阅读，产生空白或者输出的一系列字符。 

​		下面演示二进制数据和乱码：

```javascript
/*
 * 二进制数据和乱码
 */
var fs = require('fs');
fs.readFile('./test.txt',function (err, data) {
  if (err) {
    throw err;
  }
  // 1. 输出二进制数据
  console.log(data);
  // 2. 输出乱码
  console.log(data.toString());
});

```

​		同级目录下创建test.txt文件，并输入以下字符。

```text
hello 我是中文
```



![image-20200208181715179](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208181715179.png)



上述代码中，首先读取test.txt，在第10行输出读取的原始数据，是一个Buffer数组对象，该对象中存储的就是二进制数据。由于该文件是通过鼠标右键直接创建的默认编码一般是ANSI，这时，文件中包含中文字符，该编码不支持中文字符，所以会在第12行转换中文字符的过程中出现乱码，最终输出乱码。

修改test.txt文件为UTF-8编码后：

![image-20200208181727502](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200208181727502.png)

### 1.2 Buffer的构造函数

​		缓冲区是在内容中操作数据的容器，NODEJS中的Buffer缓冲区模块，支持开发者在缓冲区结构中创建、读取、写入和操作二进制数据，该模块是全局的，所以在使用时不需要使用require()函数来加载

创建Buffer实例对象需要使用Buffer的构造函数,参数分为以下几种：

- new Buffer(array)

- new Buffer(buffer)

- new Buffer(arrayBuffer[, byteOffset [, length]])

- new Buffer(size)

- new Buffer(str[, encoding])

  ​	从上述方式中可以看出Buffer构造函数用于创建Buffer对象，其中的参数可以是字节(size)，数组(array),buffer对象，字符串(str)等。

  ```javascript
  //方法1．传入字节
  var buf = new Buffer(size);
  //方法2．传入数组
  var buf = new Buffer([10, 20, 30, 40, 50]);
  //方法3. 传入字符串和编码
  var buf = new Buffer("hello", "utf-8");
  ```

  在上述方法中，'hello'为JavaScript字符串，Buffer和JavaScript字符串对象之间的转换需要显式地调用编码方法来完成，"utf-8"为Buffer默认支持的编码方式，可能省略。

  除utf-8编码外，Buffer同样支持以下编码, ascii, utf16le,ucs2,base64, hex

### 1.3 写入缓冲区

​		在进行文件复制的过程中，首先要将源文件的数据读取出来，写入Buffer中。写入 Node.js缓冲区的语法如下所示。

```javascript
buf.write(string[, offset[, length]][, encoding]); 
```

上述语法执行后将返回实际写入的大小。如果buffer空间不足，则只会写入部分字符串。各参数说明如下表。

| **参数** | **说明**                            |
| -------- | ----------------------------------- |
| string   | 写入缓冲区的字符串                  |
| offset   | 缓冲区开始写入的索引值，默认为 0    |
| length   | 写入的字节数，默认为  buffer.length |
| encoding | 使用的编码。默认为  'utf8'          |

```javascript
/*
 * 写入缓冲区
 */
//创建一个可以存储 5 个字节的内存空间对象
 var buf = new Buffer(5);
 // 通过 buffer 对象的 length 属性可以获取 buffer 缓存中的字节大小
 console.log(buf.length);
//向缓冲区写入a
 buf.write('a');
//输出缓冲区数据
 console.log(buf);
//向缓冲区写入b
 buf.write('b', 1, 1, 'ascii');
//输出缓冲区数据
 console.log(buf);
```

第13行写入b,需要注意的是写入b时需要在第二个参数传入缓冲区开始写入的索引值，因为0的位置已经被占用了，第三个参数表示传入的字节数，这里一个英文字母占一个字节。

![image-20200209111159786](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200209111159786.png)

第一行输出了字节数5，后面两行分别输出了写入数据后缓冲区的情况，在ascii编码表中字母a的十六进制数表示为61,战胜一个字节，b表示为62，占用一个字节。

### 1.4 从缓冲区读取数据

​		在进行文件复制时，源文件的数据写入缓冲区后，还需要从缓冲区中读取出来并且写入目标文件。读取 Node.js 缓冲区数据的语法如下所示：

```javascript
buf.toString([encoding[, start[, end]]])；
```

上述语法执行后将解码缓冲区数据并使用指定的编码返回字符串

| **参数** | **说明**                         |
| -------- | -------------------------------- |
| encoding | 使用的编码。默认为 'utf8'        |
| start    | 指定开始读取的索引位置，默认为 0 |
| end      | 结束位置，默认为缓冲区的末尾     |

在前面学习文件读取的过程中，曾经调用过data.toString()函数，这个data就是一个Buffer对象，等价于上述语法中的buf。

```javascript
/*
 * 读取缓冲区
 */
//创建一个可以存储26个字节的内存空间对象
 var buf = new Buffer(26);
//像buffer数组中存入26个字母对应的编码
for (var i = 0 ; i < 26 ; i++) {
 buf[i] = i + 97;
}
//输出全部字母
console.log( buf.toString('ascii'));       // 输出: abcdefghijklmnopqrstuvwxyz
//输出前五个字母
console.log( buf.toString('ascii',0,5));   // 输出: abcde
// 输出: 'abcde'
console.log(buf.toString('utf8',0,5));
// 输出: 'abcde', 默认编码为 'utf8'
console.log(buf.toString(undefined,0,5));
```

### 1.5拼接缓冲区

在实际开发中，有时会遇到这样的需求，输出两个或多个缓冲区中内容的组合。为了解决这样的需求，Node .js中提供拼接缓冲区的函数，语法如下所示：

```javascript
buf.concat(list[, totalLength]);
```

上述语法执行后返回一个多个成员合并的新Buffer 对象。其中list用于合并的 Buffer 对象数组列表，totalLength用于指定合并后Buffer对象的总长度。

```javascript
/*
 * 拼接缓冲区
 */
//创建两个缓冲区
 var buf = new Buffer('世上无难事，');
 var buf1 = new Buffer('只怕有心人');
//执行拼接操作
var buf2= Buffer.concat([buf,buf1]);
//输出拼接后缓冲区的内容
console.log("buf2 内容: " + buf2.toString());
```

![image-20200209115524321](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200209115524321.png)

## 二 Stream文件流

​		由于Buffer缓冲区限制在1GB，超过1GB的文件无法直接完成读写，并且，如果有些读写资源一直持续，并不停止，Node.js将无法继续其他工作。所以用Node.js处理大数据文件的读写时会出现问题。为此，Node.js提供了Stream文件流模块，用来解决大数据文件操作的问题。

### 2.1文件流的概念

Node.js的File System模块并没有提供一个copy的方法，但是通过读取文件和写入文件的方式可以实现，即把文件A的内容全部读入Buffer缓冲区，然后再从缓冲区读出写入文件B，该过程的执行流程图如下图所示。

![image-20200209120625089](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200209120625089.png)

上图这样的操作对于小型文件不大于1G的文件没问题，但是对于体积软大的文件，比如音频、视频文件，动辄几吉字节大小，如果使用这种方法，很容易使内存“爆仓”，理想的方法应用是读一部分，写一部分，不管文件有多大，只要时间允许，总会处理完成，这里就需要用于流的概念，文件复制操作使用文件流的读/写机制进行会防止“爆仓”现象的出现。

由于Buffer缓冲区限制在1GB，对于大文件的操作，理想的实现方式是“读一部分，写一部分”，流程如下图所示。

<img src="D:/2020课件/6Nodejs/年前/教案/文档中的图片/clip_image002.png" alt="img" style="zoom:200%;" />

文件A中数据以流动的形式通过数据流管道，然后进入到文件B中，采用“读一部分，写一部分”的方式。流的好处是接收方可以提前处理，缩短等待时间，提高速度。例如，在网络上观看视频，并不是整个视频下载好了才播放的，而下一点播放一点。

​		在Node.js中，文件流的操作由Stream模块提供，Stream 是一个抽象接口，Node.js 中还有很多对象实现了这个接口。例如： 对HTTP服务器发起请求的request对象就是一个Stream，还有stdout(标准输出)等

​		Node.js，Stream 有四种流类型：

* Readable - 可读操作。

* Writable - 可写操作。

* Duplex - 可读可写操作.

* Transform - 操作被写入数据，然后读出结果。

在nodejs中，很多模块涉及流的读/写，例如， HTTP requests和response、Standard input/output、 File reads and writes。nodejs中的I/O是异步的，因此对磁盘和网络的读/写需要通过回调函数来读取数据，而回调函数需要通过事件来触发，所有的Stream对象都是 EventEmitter(事件触发器)的实例。

主要介绍前两种Readable Stream(可读流)和Writable Stream(可写流)。

| 事件   | 说明                             |
| ------ | -------------------------------- |
| data   | 当有数据可读时触发               |
| end    | 没有更多的数据可读时触发         |
| error  | 在接收和写入过程中发生错误时触发 |
| finish | 所有数据已被写入到底层系统时触发 |

### 2.2 Nodejs的可读流和可写流

​		与Buffer的读/写操作类型，Stream中的可读流和可写流也用于读/写操作。

#### 1.可读流

使用文件流进行文件复制，首先需要把文件流中的数据读取出来，而这个读取过程需要我们创建一个可读流(Readable Stream)，可读流可以让我们在源文件中分块读取文件中的数据，在Node.js中，创建可读流的语法如下所示。

```javascript
fs.createReadStream(path[, options]);
```

在上述语法中，path代表文件路径，options是一组key-value值，常用的设置如下表所示。

| **值**   | **说明**                                                     |
| -------- | ------------------------------------------------------------ |
| flags    | 对文件进行何种操作，默认为'r'，读文件                        |
| encoding | 指定编码，默认为null,如果不设置具体的编码格式，读出的数据就是Buffer类型；也可以使用rs.setEncoding("utf-8")指定编码格式 |
| start    | 从start开始读取文件                                          |
| end      | 读取文件到end为止(包括end)                                   |

由于流是基于EventEmitter的，从流读取数据最好的方法是监听数据事件(data, event), 并附加一个回调函数，当一个数据块有效时，可读流会触发一个`data`事件并执行回调函数，返回数据是循环进制的，一直到读取完毕。在读取发生错误或者读取完毕就会触发`error`或者`end`事件。

​		下面通过一个案例演示如何从流中读取数据。

​		input.txt

```c
老师是我心中的太阳，她教给了我们知识。
```

​		demo5-5.js

```javascript
/**
 *  从流中读取数据
 */
var fs = require("fs");
var total = '';
// 创建可读流
var readableStream = fs.createReadStream('input.txt');
// 设置编码为 utf8。
readableStream.setEncoding('UTF8');
// 处理流事件 data\end\and\error
readableStream.on('data', function(chunk) {
    total += chunk;
});
readableStream.on('end',function(){
    console.log(total);
});
readableStream.on('error', function(err){
    console.log(err.stack);
});
console.log("程序执行完毕");
```

​		上述代码中，由于创建可读流的createReadStream()函数由fs模块提供，所以需要首先加载fs模块，创建完成后readableStream这个流是一个静止的状态。

​		在第11行绑定了data事件，并附加了一个回调函数的时候，流就开始流动。之后数据就会通过chunk参数流向（传递）给回调函数。chunk参数代表触发data事件后返回的数据块，每返回一次都在第12行追加到total中，		第14~16行用于处理流事件end,在读取结束后输出数据total。

​		第17~19行用来处理流的错误事件error。

​		![image-20200209174456635](D:/2020课件/6Nodejs/年前/教案/文档中的图片/image-20200209174456635.png)

​		因为流事件的操作都是异步的。

#### 2.可写流

可写流(Writable Stream)让我们可以写数据到目的地，像可读流一样，它也是基于EventEmitter。在Node.js中，创建可读流的语法如下所示。

```javascript
fs.createWriteStream(path[, options]);
```

在上述语法中，path代表文件路径，options是一组key-value值，常用的设置如下表所示。

| **值**   | **说明**                                                     |
| -------- | ------------------------------------------------------------ |
| flags    | 对文件进行何种操作，默认为'w'，写文件                        |
| encoding | 指定编码，默认为null,如果不设置具体的编码格式，读出的数据就是Buffer类型；也可以使用rs.setEncoding("utf-8")指定编码格式 |
| start    | 从start开始写入文件                                          |
| end      | 写入文件到end为止(包括end)                                   |

​		把一个数据写到可写流中需要调用流的实例方法write()，结合可读流的知识，就可以完成大文件的复制案例，为了方便操作这里使用词本文件。

​		input.txt

```javascript
老师是我心中的太阳，她教给了我们知识。
```

​		demo5-6.js

```javascript
/**
 *  使用文件流进行文件拷贝
 */
var fs = require('fs');
//创建可读流
var readableStream = fs.createReadStream('input.txt');
//创建可写流
var writableStream = fs.createWriteStream('output.txt');
readableStream.setEncoding('utf8');
readableStream.on('data', function(chunk){
    //将读出的数据块写入可写流
    writableStream.write(chunk);
});
readableStream.on('error', function(err){
    console.log(err.stack);
});
readableStream.on('end',function(){
    //将剩下的数据全部写入，并且关闭写入的文件
    writableStream.end();
});
writableStream.on('error', function(err){
    console.log(err.stack);
});
```

​		在当前目录可以看到output.txt文件，打开output.txt文件，可以看到与input.txt文件中相同的内容。

### 2.3使用pipe()处理大文件

​		在使用大文件复制的案例中，通过可读流的chunk参数来传递数据，如果把数据比作是水，这个chunk就相当于盆，使用盆来完成水的传递。在可读流中还有一个函数叫作pipe(), 这个函数是一个很高效的文件处理方式，可以简化之前复制文件的操作，pipe翻译成中文是管子的意思，使用pipe()进行文件复制相当于把盆换成管子，通过管子来完成数据的读取和写入。

​		下面通过案例来演示如何使用pipe处理大文件复制，

​		input.txt

```javascript
老师是我心中的太阳，她教给了我们知识
```

​		demo5-7.js

```javascript
/**
 *  使用pipe()进行文件拷贝
 */
var fs = require('fs')
//源文件路径
var srcPath = './input.txt';
//目标文件路径
var distPath = './output.txt';
var readableStream = fs.createReadStream(srcPath);
var writableStream = fs.createWriteStream(distPath);
// 可以通过使用可读流 的函数 pipe ()接入到可写流中
// pipe()是一个很高效的数据处理方式

if(readableStream.pipe(writableStream)){
    console.log('文件复制成功了')
}else{
    console.log('文件复制失败了')
}
```



# 一、fs.createReadStream 

从文件流中读取数据,和以前不一样，是一块一块读取的，每读到一块数据给我们广播一个`data`

## 流的方式读取文件

```js
const fs = require('fs')
var readStream=fs.createReadStream(__dirname+'/input.txt');

var str='';/*保存数据*/
var count=0;  /*次数*/
readStream.on('data',function(chunk){
    str+=chunk;
    count++;
})

//读取完成
readStream.on('end',function(chunk){
    console.log(count);
    console.log(str);
})
//读取失败
readStream.on('error',function(err){
    console.log(err);

})
```

文件大的时候使用流的方式，不至于卡死

# 二、fs.createWriteStream 

写入文件

```js
var fs = require("fs");
var data = '我是从数据库获取的数据，我要保存起来11\n';

// 创建一个可以写入的流，写入到文件 output.txt 中
var writerStream = fs.createWriteStream('output.txt');
for(var i=0;i<100;i++){
    writerStream.write(data,'utf8');
}
//标记写入完成
writerStream.end();


writerStream.on('finish',function(){

    console.log('写入完成');
})

//失败
writerStream.on('error',function(){

    console.log('写入失败');
})

```

追加数据

```js
// 2.原内容后追加
var writeStream = fs.createWriteStream('pipe.txt',{ 'flags': 'a' })
```

# 三、管道流

管道提供了一个输出流到输入流的机制。通常我们用于从一个流中获取数据并将数据传递到另外一个流中。

![image-20200823103245830](images\image-20200823103245830.png)

如上面的图片所示，我们把文件比作装水的桶，而水就是文件里的内容，我们用一根管子(pipe)连接两个桶使得水从一个桶流入另一个桶，这样就慢慢的实现了大文件的复制过程。 以下实例我们通过读取一个文件内容并将内容写入到另外一个文件中。

```js
var fs = require("fs");


// 创建一个可读流
var readerStream = fs.createReadStream('input.txt');

// 创建一个可写流
var writerStream = fs.createWriteStream('output.txt');

// 管道读写操作
// 读取 input.txt 文件内容，并将内容写入到 output.txt 文件中
readerStream.pipe(writerStream);

console.log("程序执行完毕");
```


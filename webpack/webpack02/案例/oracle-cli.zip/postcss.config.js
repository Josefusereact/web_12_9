module.exports = {
	plugins: {
		'postcss-preset-env': {},//处理兼容性
		'cssnano':{}//压缩样式
	}
}
const { merge } = require('webpack-merge');
const base = require('./webpack.base.js')
const path = require('path')
module.exports = merge(base,{
	mode:'development',
	devServer:{
		contentBase:[
			path.resolve(__dirname,'dist'),
			path.resolve(__dirname,'public')
		],
		host:'localhost',
		port:8080,
		open:true,
		openPage:''
	},
	module:{
		rules:[
			{ //用来编译css代码
				test:/\.css$/,
				use:[
					{loader:'style-loader'},
					{loader:'css-loader'},
					{loader:'postcss-loader'},
				]
			},
			{ //用来编译sass代码
				test:/\.scss$/,
				use:[
					{loader:'style-loader'},
					{loader:'css-loader'},
					{loader:'postcss-loader'},
					{loader:'sass-loader'}
				]
			}
		]
	},
	devtool:'inline-source-map'//内联配置源码映射
})
import './index.scss'//注意es6模块引用需要在前面用./或../
import '@/css/style'
let array = [123, new Date(), new Error()];
import img from '@/assets/img1.png'
console.log(img)
document.querySelector('#img').src = img
array.map(item=>{
    //typeof 只能返回 string, number, object, function , undefined这几个值
    if(item instanceof Date){
        console.log(item.getDate());
    }
})